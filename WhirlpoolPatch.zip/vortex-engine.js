console.log("Whirlpool patch is working");

const _loadingScreen = document.createElement("div");
_loadingScreen.id = "vortex-loading-screen";
const _loadingLogo = document.createElement("div");
_loadingLogo.id = "vortex-loading-logo";
_loadingLogo.textContent = "VORTEX";
const _loadingBarBg = document.createElement("div");
_loadingBarBg.id = "vortex-loading-bar-bg";
const _loadingBarFill = document.createElement("div");
_loadingBarFill.id = "vortex-loading-bar-fill";
const _loadingText = document.createElement("div");
_loadingText.id = "vortex-loading-text";
_loadingBarBg.appendChild(_loadingBarFill);
_loadingScreen.appendChild(_loadingLogo);
_loadingScreen.appendChild(_loadingBarBg);
document.body.appendChild(_loadingScreen);
let _worldBuilt = false;
THREE.DefaultLoadingManager.onStart = function (_0x5e42ef, _0x4e4f67, _0x24d825) {
  if (_worldBuilt) {
    return;
  }
  _loadingScreen.classList.remove("hidden");
};
THREE.DefaultLoadingManager.onProgress = function (_0x31134a, _0x272be6, _0x9e4b80) {
  if (_worldBuilt) {
    return;
  }
  _loadingBarFill.style.width = _0x272be6 / _0x9e4b80 * 100 + "%";
};
THREE.DefaultLoadingManager.onLoad = function () {};
const STUDS_PER_TILE = 4;
const scene = new THREE.Scene();
scene.fog = new THREE.Fog(8900331, 192, 480);
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 3200);
const renderer = new THREE.WebGLRenderer({
  antialias: window._options.aa
});
window.renderer = renderer;

renderer.setClearColor(8900331);
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.setPixelRatio(window._options.pixelRatio);
document.getElementById("scene").appendChild(renderer.domElement);
window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
const ambient = new THREE.AmbientLight(16777215, 0.45);
scene.add(ambient);
const sun = new THREE.DirectionalLight(16777215, 0.85);
window.sun = sun;
sun.position.set(160, 320, 160);
sun.castShadow = true;
sun.shadow.mapSize.width = 2048;
sun.shadow.mapSize.height = 2048;
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 960;
sun.shadow.camera.left = -192;
sun.shadow.camera.right = 192;
sun.shadow.camera.top = 192;
sun.shadow.camera.bottom = -192;
sun.shadow.autoUpdate = window._options.shadows;
scene.add(sun);
const tlLoader = new THREE.TextureLoader();
const texCache = new Map();
function studTex(_0x210f57, _0x27c494) {
  const _0x35f6f9 = tlLoader.load("assets/textures/stud.jpeg");
  _0x35f6f9.wrapS = _0x35f6f9.wrapT = THREE.RepeatWrapping;
  _0x35f6f9.repeat.set(_0x210f57, _0x27c494);
  return _0x35f6f9;
}
const geoCache = new Map();
const matCache = new Map();
function getCachedGeo(_0x5b227d, _0x1cf733, _0x550822) {
  const _0x41fc15 = _0x5b227d + "," + _0x1cf733 + "," + _0x550822;
  if (!geoCache.has(_0x41fc15)) {
    geoCache.set(_0x41fc15, new THREE.BoxGeometry(_0x5b227d, _0x1cf733, _0x550822));
  }
  return geoCache.get(_0x41fc15);
}
function getCachedMats(_0x498702, _0x37d6d6, _0x2b3faa, _0x330358) {
  const _0x1f4e89 = _0x498702 + "," + _0x37d6d6 + "," + _0x2b3faa + "," + _0x330358;
  if (matCache.has(_0x1f4e89)) {
    return matCache.get(_0x1f4e89);
  }
  const _0x181060 = (_0x42987c, _0x3f29d6) => new THREE.MeshLambertMaterial({
    color: _0x330358,
    map: studTex(_0x42987c, _0x3f29d6)
  });
  const _0x7e15f1 = [_0x181060(_0x2b3faa / STUDS_PER_TILE, _0x37d6d6 / STUDS_PER_TILE), _0x181060(_0x2b3faa / STUDS_PER_TILE, _0x37d6d6 / STUDS_PER_TILE), _0x181060(_0x498702 / STUDS_PER_TILE, _0x2b3faa / STUDS_PER_TILE), _0x181060(_0x498702 / STUDS_PER_TILE, _0x2b3faa / STUDS_PER_TILE), _0x181060(_0x498702 / STUDS_PER_TILE, _0x37d6d6 / STUDS_PER_TILE), _0x181060(_0x498702 / STUDS_PER_TILE, _0x37d6d6 / STUDS_PER_TILE)];
  matCache.set(_0x1f4e89, _0x7e15f1);
  return _0x7e15f1;
}
const instancedMeshes = new Map();
const MAX_INSTANCES = 1024;
function getInstanceKey(_0x164cb5, _0x141db7, _0x291331, _0x29ebd2) {
  return _0x164cb5 + "," + _0x141db7 + "," + _0x291331 + "," + _0x29ebd2;
}
function flushInstances() {
  for (const [, _0x3f0aeb] of instancedMeshes) {
    _0x3f0aeb.mesh.count = _0x3f0aeb.count;
    _0x3f0aeb.mesh.instanceMatrix.needsUpdate = true;
  }
}
const _dummy = new THREE.Object3D();
function addStud(_0x56c764, _0x48456b, _0x1b25eb, _0x19731c, _0x36d988, _0x409c05, _0x48ffaa, _0x2ad672 = 0, _0x171d85 = 0, _0x101baf = 0) {
  const _0x14c16b = new THREE.Mesh(getCachedGeo(_0x56c764, _0x48456b, _0x1b25eb), getCachedMats(_0x56c764, _0x48456b, _0x1b25eb, _0x19731c));
  const _0x14b70f = _0x409c05 + _0x48456b / 2;
  _0x14c16b.position.set(_0x36d988, _0x14b70f, _0x48ffaa);
  if (_0x2ad672 !== 0 || _0x171d85 !== 0 || _0x101baf !== 0) {
    _0x14c16b.rotation.set(_0x2ad672, _0x171d85, _0x101baf);
  }
  _0x14c16b.castShadow = true;
  _0x14c16b.receiveShadow = true;
  scene.add(_0x14c16b);
  if (_0x2ad672 === 0 && _0x171d85 === 0 && _0x101baf === 0) {
    const _0x4abbf3 = {
      minX: _0x36d988 - _0x56c764 / 2,
      maxX: _0x36d988 + _0x56c764 / 2,
      minY: _0x409c05,
      maxY: _0x409c05 + _0x48456b,
      minZ: _0x48ffaa - _0x1b25eb / 2,
      maxZ: _0x48ffaa + _0x1b25eb / 2
    };
    colliders.push(_0x4abbf3);
    insertToChunks(_0x4abbf3);
  } else {
    const _0x20473 = buildOBB(_0x56c764, _0x48456b, _0x1b25eb, _0x36d988, _0x14b70f, _0x48ffaa, _0x2ad672, _0x171d85, _0x101baf);
    colliders.push(_0x20473);
    insertToChunks(_0x20473);
  }
  return _0x14c16b;
}
function buildOBB(_0x2dccd8, _0x4e2e27, _0x4672d0, _0x2e396d, _0x3127d4, _0x49b7cd, _0x182acb, _0x4c58b7, _0x52c941) {
  const _0x44e60f = new THREE.Matrix4().makeRotationFromEuler(new THREE.Euler(_0x182acb, _0x4c58b7, _0x52c941));
  const _0x34bb0f = _0x44e60f.elements;
  const _0x3b90a3 = _0x34bb0f[0];
  const _0x44b7f8 = _0x34bb0f[1];
  const _0x5c5039 = _0x34bb0f[2];
  const _0x2c59e0 = _0x34bb0f[4];
  const _0x3b6812 = _0x34bb0f[5];
  const _0xaced3e = _0x34bb0f[6];
  const _0x49ff0c = _0x34bb0f[8];
  const _0x5dbd0d = _0x34bb0f[9];
  const _0x477a7d = _0x34bb0f[10];
  const _0x5125c1 = _0x2dccd8 / 2;
  const _0x1c1323 = _0x4e2e27 / 2;
  const _0x53b282 = _0x4672d0 / 2;
  const _0x2e3e7a = _0x5125c1 * Math.abs(_0x3b90a3) + _0x1c1323 * Math.abs(_0x2c59e0) + _0x53b282 * Math.abs(_0x49ff0c);
  const _0x4cdd91 = _0x5125c1 * Math.abs(_0x44b7f8) + _0x1c1323 * Math.abs(_0x3b6812) + _0x53b282 * Math.abs(_0x5dbd0d);
  const _0x30896b = _0x5125c1 * Math.abs(_0x5c5039) + _0x1c1323 * Math.abs(_0xaced3e) + _0x53b282 * Math.abs(_0x477a7d);
  return {
    isOBB: true,
    cx: _0x2e396d,
    cy: _0x3127d4,
    cz: _0x49b7cd,
    hx: _0x5125c1,
    hy: _0x1c1323,
    hz: _0x53b282,
    ux: _0x3b90a3,
    uy: _0x44b7f8,
    uz: _0x5c5039,
    vx: _0x2c59e0,
    vy: _0x3b6812,
    vz: _0xaced3e,
    wx: _0x49ff0c,
    wy: _0x5dbd0d,
    wz: _0x477a7d,
    minX: _0x2e396d - _0x2e3e7a,
    maxX: _0x2e396d + _0x2e3e7a,
    minY: _0x3127d4 - _0x4cdd91,
    maxY: _0x3127d4 + _0x4cdd91,
    minZ: _0x49b7cd - _0x30896b,
    maxZ: _0x49b7cd + _0x30896b
  };
}
const ground = new THREE.Mesh(getCachedGeo(320, 3.2, 320), getCachedMats(320, 3.2, 320, 5093451));
ground.receiveShadow = true;
scene.add(ground);
const colliders = [];
const CHUNK_SIZE = 4;
const chunkMap = new Map();
function chunkKey(_0x449434, _0x567a86, _0xf6c996) {
  return _0x449434 + "," + _0x567a86 + "," + _0xf6c996;
}
function worldToChunk(_0x379c66) {
  return Math.floor(_0x379c66 / CHUNK_SIZE);
}
function insertToChunks(_0x1bc033) {
  const _0x58d366 = worldToChunk(_0x1bc033.minX);
  const _0x148909 = worldToChunk(_0x1bc033.maxX);
  const _0x52dfe8 = worldToChunk(_0x1bc033.minY);
  const _0x454082 = worldToChunk(_0x1bc033.maxY);
  const _0x5c7783 = worldToChunk(_0x1bc033.minZ);
  const _0xdfa06b = worldToChunk(_0x1bc033.maxZ);
  for (let _0x5a2a46 = _0x58d366; _0x5a2a46 <= _0x148909; _0x5a2a46++) {
    for (let _0x4f2575 = _0x52dfe8; _0x4f2575 <= _0x454082; _0x4f2575++) {
      for (let _0x4efb61 = _0x5c7783; _0x4efb61 <= _0xdfa06b; _0x4efb61++) {
        const _0x17d5ee = chunkKey(_0x5a2a46, _0x4f2575, _0x4efb61);
        if (!chunkMap.has(_0x17d5ee)) {
          chunkMap.set(_0x17d5ee, new Set());
        }
        chunkMap.get(_0x17d5ee).add(_0x1bc033);
      }
    }
  }
}
const _nearbySet = new Set();
function getNearbyColliders(_0x5de218, _0x1df3d5, _0x464306) {
  _nearbySet.clear();
  const _0x418ee6 = worldToChunk(_0x5de218);
  const _0xbf593e = worldToChunk(_0x1df3d5);
  const _0x9cfb93 = worldToChunk(_0x464306);
  for (let _0x2c53ec = -1; _0x2c53ec <= 1; _0x2c53ec++) {
    for (let _0x551ddc = -1; _0x551ddc <= 1; _0x551ddc++) {
      for (let _0x2a8901 = -1; _0x2a8901 <= 1; _0x2a8901++) {
        const _0xfc685a = chunkMap.get(chunkKey(_0x418ee6 + _0x2c53ec, _0xbf593e + _0x551ddc, _0x9cfb93 + _0x2a8901));
        if (_0xfc685a) {
          _0xfc685a.forEach(_0x24fd0b => _nearbySet.add(_0x24fd0b));
        }
      }
    }
  }
  return _nearbySet;
}
const G = 1.6;
let CHAR_STAND_Y = 3.68;
const WALK_SPEED = window._options.ws;
const JUMP_POWER = window._options.jp;
const GRAVITY = window._options.g;
const ROT_SPEED = window._options.rotS;
const STEP_HEIGHT = window._options.sH;
const STEP_CLIMB_SPEED = window._options.climbS;
let CHAR_FOOT_OFFSET = 2.08;
let CHAR_HEIGHT = 5;
let CHAR_HALF_W = 1;
let CHAR_HALF_D = 0.5;
let CAM_H_SENS = Math.PI * 0.002;
let CAM_V_SENS = Math.PI * 0.0015;
const CAM_PIVOT_Y = 2.56;
const SHIFT_LOCK_OFFSET = 1.75;
const CAM_KEY_ZOOM_SPEED = 32;
let debugMode = false;
const debugMeshes = [];
let charDebugMesh = null;
let chunkZoneMesh = null;
function makeWireBox(_0x5dc77c, _0x5094c1, _0x1cb47d, _0x138c46, _0xa38190, _0x2dc7cc, _0x4354eb) {
  const _0x55c56a = new THREE.EdgesGeometry(new THREE.BoxGeometry(_0x138c46 - _0x5dc77c, _0xa38190 - _0x5094c1, _0x2dc7cc - _0x1cb47d));
  const _0x267440 = new THREE.LineBasicMaterial({
    color: _0x4354eb,
    depthTest: false
  });
  const _0x45e575 = new THREE.LineSegments(_0x55c56a, _0x267440);
  _0x45e575.position.set((_0x5dc77c + _0x138c46) / 2, (_0x5094c1 + _0xa38190) / 2, (_0x1cb47d + _0x2dc7cc) / 2);
  _0x45e575.renderOrder = 999;
  return _0x45e575;
}
function makeWireOBB(_0x259c62) {
  const _0x4dffdb = new THREE.EdgesGeometry(new THREE.BoxGeometry(_0x259c62.hx * 2, _0x259c62.hy * 2, _0x259c62.hz * 2));
  const _0x1072d5 = new THREE.LineBasicMaterial({
    color: 16746496,
    depthTest: false
  });
  const _0x4794ba = new THREE.LineSegments(_0x4dffdb, _0x1072d5);
  _0x4794ba.position.set(_0x259c62.cx, _0x259c62.cy, _0x259c62.cz);
  const _0x12177e = new THREE.Matrix4();
  _0x12177e.set(_0x259c62.ux, _0x259c62.vx, _0x259c62.wx, 0, _0x259c62.uy, _0x259c62.vy, _0x259c62.wy, 0, _0x259c62.uz, _0x259c62.vz, _0x259c62.wz, 0, 0, 0, 0, 1);
  _0x4794ba.setRotationFromMatrix(_0x12177e);
  _0x4794ba.renderOrder = 999;
  return _0x4794ba;
}
function toggleDebug() {
  debugMode = !debugMode;
  if (debugMode) {
    charDebugMesh = makeWireBox(-CHAR_HALF_W, 0, -CHAR_HALF_D, CHAR_HALF_W, CHAR_HEIGHT, CHAR_HALF_D, 16729156);
    scene.add(charDebugMesh);
  } else {
    debugMeshes.forEach(_0x352cd0 => {
      _0x352cd0.geometry.dispose();
      _0x352cd0.material.dispose();
      scene.remove(_0x352cd0);
    });
    debugMeshes.length = 0;
    if (charDebugMesh) {
      charDebugMesh.geometry.dispose();
      charDebugMesh.material.dispose();
      scene.remove(charDebugMesh);
      charDebugMesh = null;
    }
    if (chunkZoneMesh) {
      chunkZoneMesh.geometry.dispose();
      chunkZoneMesh.material.dispose();
      scene.remove(chunkZoneMesh);
      chunkZoneMesh = null;
    }
  }
}
function updateDebugMeshes() {
  if (!debugMode || !character) {
    return;
  }
  debugMeshes.forEach(_0x4c6c9b => {
    _0x4c6c9b.geometry.dispose();
    _0x4c6c9b.material.dispose();
    scene.remove(_0x4c6c9b);
  });
  debugMeshes.length = 0;
  if (chunkZoneMesh) {
    chunkZoneMesh.geometry.dispose();
    chunkZoneMesh.material.dispose();
    scene.remove(chunkZoneMesh);
    chunkZoneMesh = null;
  }
  const _0xa6c3d3 = character.position.x;
  const _0xb5541e = character.position.z;
  const _0x1636b4 = getNearbyColliders(_0xa6c3d3, character.position.y, _0xb5541e);
  for (const _0x5ed1b5 of _0x1636b4) {
    let _0xdeaaae;
    if (_0x5ed1b5.isOBB) {
      _0xdeaaae = makeWireOBB(_0x5ed1b5);
    } else {
      _0xdeaaae = makeWireBox(_0x5ed1b5.minX, _0x5ed1b5.minY, _0x5ed1b5.minZ, _0x5ed1b5.maxX, _0x5ed1b5.maxY, _0x5ed1b5.maxZ, 16776960);
    }
    scene.add(_0xdeaaae);
    debugMeshes.push(_0xdeaaae);
  }
  const _0x47c20f = worldToChunk(_0xa6c3d3);
  const _0x56c82c = worldToChunk(_0xb5541e);
  const _0xd2d172 = (_0x47c20f - 1) * CHUNK_SIZE;
  const _0x57f064 = (_0x47c20f + 2) * CHUNK_SIZE;
  const _0x467b60 = (_0x56c82c - 1) * CHUNK_SIZE;
  const _0x18194f = (_0x56c82c + 2) * CHUNK_SIZE;
  const _0xdac1bd = 512;
  chunkZoneMesh = makeWireBox(_0xd2d172, -_0xdac1bd / 2, _0x467b60, _0x57f064, _0xdac1bd / 2, _0x18194f, 52479);
  scene.add(chunkZoneMesh);
}
let velY = 0;
let grounded = true;
let stepUpTarget = -Infinity;
const pushedBlocks = new Set();
let shiftLock = false;
let locked = false;
let coyoteTimer = 0;
let jumpBuffer = 0;
const COYOTE_TIME = 0.12;
const JUMP_BUFFER = 0.15;
let climbState = "none";
let climbLedgeY = 0;
let climbFwdX = 0;
let climbFwdZ = 0;
let climbBlock = null;
let climbCooldown = 0;
const CLIMB_RISE_SPEED = 11.2;
const CLIMB_SIDE_SPEED = 11.2;
const CLIMB_REACH = 0.1;
const CLIMB_FALL_CUTOFF = -200;
const CLIMB_MAX_PART_H = 1.5;
const CLIMB_WINDOW = 2.2;
const CLIMB_JUMP_UP = 38;
const CLIMB_JUMP_BACK_V = 14;
const HANG_DEPTH = 1.2;
let extraVelX = 0;
let extraVelZ = 0;
const overlay = document.getElementById("overlay");
const crosshair = document.getElementById("crosshair");
const cursorEl = document.getElementById("cursor");
let cursorX = window.innerWidth / 2;
let cursorY = window.innerHeight / 2;
const anim = {
  time: 0,
  bones: {},
  rest: {}
};
function getBone(..._0x1ea5ea) {
  for (const _0x5416bf of _0x1ea5ea) {
    if (anim.bones[_0x5416bf]) {
      return anim.bones[_0x5416bf];
    }
  }
  return null;
}
let character = null;
let _spawnPoint = {
  x: 0,
  y: null,
  z: 0,
  ry: Math.PI
};
let _shirtMesh = null;
const fbxLoader = new THREE.FBXLoader();
fbxLoader.load("assets/models/player.fbx", _0xc980cf => {
  _0xc980cf.position.set(0, 0, 0);
  _0xc980cf.updateMatrixWorld(true);
  const _0x50e1e7 = new THREE.Box3().setFromObject(_0xc980cf);
  CHAR_FOOT_OFFSET = -_0x50e1e7.min.y;
  CHAR_HEIGHT = _0x50e1e7.max.y - _0x50e1e7.min.y;
  CHAR_STAND_Y = G + CHAR_FOOT_OFFSET;
  console.log("char foot offset:", CHAR_FOOT_OFFSET.toFixed(3), "| height:", CHAR_HEIGHT.toFixed(3));
  const _0x493388 = _spawnPoint.y !== null ? _spawnPoint.y + CHAR_FOOT_OFFSET : CHAR_STAND_Y;
  _0xc980cf.position.set(_spawnPoint.x, _0x493388, _spawnPoint.z);
  _0xc980cf.rotation.y = _spawnPoint.ry;
  _0xc980cf.castShadow = true;
  _0xc980cf.traverse(_0x21170f => {
    if (_0x21170f.isBone || _0x21170f.type === "Bone") {
      anim.bones[_0x21170f.name] = _0x21170f;
      anim.rest[_0x21170f.name] = {
        x: _0x21170f.rotation.x,
        y: _0x21170f.rotation.y,
        z: _0x21170f.rotation.z,
        px: _0x21170f.position.x,
        py: _0x21170f.position.y,
        pz: _0x21170f.position.z
      };
    }
  });
  _0xc980cf.traverse(_0x28240f => {
    if (_0x28240f.isMesh) {
      _0x28240f.castShadow = true;
    }
  });
  scene.add(_0xc980cf);
  character = _0xc980cf;
  _shirtMesh = _buildShirtOverlay(_0xc980cf);
  renderer.shadowMap.needsUpdate = true;
});
const cam = {
  yaw: 0,
  pitch: 0.35,
  distance: 25.6,
  minPitch: -0.5,
  maxPitch: 1.35,
  minDist: 3.2,
  maxDist: 128
};
const keys = {};
document.addEventListener("keydown", _0x230cc0 => {
  if (window._chatFocused) {
    return;
  }
  if (!locked) {
    return;
  }
  keys[_0x230cc0.code] = true;
  if (_0x230cc0.code === "ShiftLeft" || _0x230cc0.code === "ShiftRight") {
    shiftLock = !shiftLock;
    crosshair.style.display = shiftLock ? "block" : "none";
    cursorEl.style.display = shiftLock ? "none" : "block";
    if (!shiftLock) {
      cursorX = window.innerWidth / 2;
      cursorY = window.innerHeight / 2;
      cursorEl.style.transform = "translate(" + cursorX + "px, " + cursorY + "px)";
      if (character) {
        character.rotation.y = (character.rotation.y % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
        if (character.rotation.y > Math.PI) {
          character.rotation.y -= Math.PI * 2;
        }
      }
    }
  }
  if (_0x230cc0.code === "Comma") {
    cam.yaw = Math.round((cam.yaw + Math.PI / 4) / (Math.PI / 4)) * (Math.PI / 4);
  }
  if (_0x230cc0.code === "Period") {
    cam.yaw = Math.round((cam.yaw - Math.PI / 4) / (Math.PI / 4)) * (Math.PI / 4);
  }
  if (_0x230cc0.code === "Space") {
    jumpBuffer = JUMP_BUFFER;
  }
  if (_0x230cc0.code === "Backquote") {
    toggleDebug();
  }
});
document.addEventListener("keyup", _0x23f4fe => {
  keys[_0x23f4fe.code] = false;
});
document.addEventListener("pointerlockchange", () => {
  locked = !!document.pointerLockElement;
  if (locked) {
    overlay.classList.add("hidden");
    cursorEl.style.transform = "translate(" + cursorX + "px, " + cursorY + "px)";
  } else {
    overlay.classList.remove("hidden");
    Object.keys(keys).forEach(_0x2cc009 => keys[_0x2cc009] = false);
    rmb = false;
  }
});
let rmb = false;
let _sliderDrag = null;
function _cursorOver(_0x394177) {
  if (!_0x394177) {
    return false;
  }
  const _0x1405a3 = _0x394177.getBoundingClientRect();
  return cursorX >= _0x1405a3.left && cursorX <= _0x1405a3.right && cursorY >= _0x1405a3.top && cursorY <= _0x1405a3.bottom;
}
renderer.domElement.addEventListener("contextmenu", _0x12ef2e => _0x12ef2e.preventDefault());
renderer.domElement.addEventListener("click", () => {
  if (locked) {
    const _0x4ed89e = _cursorOver;
    const _0x250cde = document.getElementById("chat-window");
    const _0x3c054f = document.getElementById("hud-topbar");
    const _0x3e6378 = document.getElementById("lb-player-panel");
    const _0xec6055 = document.getElementById("lb-body");
    if (_0x250cde && !_0x250cde.classList.contains("hidden") && _0x4ed89e(_0x250cde)) {
      const _0x39d8a3 = document.getElementById("chat-send");
      if (_0x39d8a3 && _0x4ed89e(_0x39d8a3)) {
        window.Chat?.send();
      } else {
        window.Chat?.activate();
      }
      return;
    }
    if (_0x4ed89e(_0x3c054f)) {
      for (const _0x586689 of _0x3c054f.children) {
        if (_0x4ed89e(_0x586689)) {
          _0x586689.click();
          break;
        }
      }
      return;
    }
    if (_0x3e6378 && _0x3e6378.style.display !== "none" && _0x4ed89e(_0x3e6378)) {
      for (const _0x367103 of _0x3e6378.querySelectorAll("button, a")) {
        if (_0x4ed89e(_0x367103)) {
          _0x367103.click();
          return;
        }
      }
      return;
    }
    if (_0xec6055) {
      for (const _0x106e15 of _0xec6055.querySelectorAll("[data-player-id]")) {
        if (_0x4ed89e(_0x106e15)) {
          window.Leaderboard?.selectPlayer(parseInt(_0x106e15.dataset.playerId));
          return;
        }
      }
    }
    const _0x917c53 = document.getElementById("notif-container");
    if (_0x917c53) {
      for (const _0x163847 of _0x917c53.querySelectorAll(".notif-btn:not(:disabled)")) {
        if (_0x4ed89e(_0x163847)) {
          _0x163847.click();
          return;
        }
      }
    }
    if (window._chatFocused) {
      window.Chat?.deactivate();
      return;
    }
    if (window._onEngineClick?.()) {
      return;
    }
    window.Leaderboard?.closeFriendPanel();
  }
  renderer.domElement.requestPointerLock();
});
overlay.addEventListener("click", () => renderer.domElement.requestPointerLock());
renderer.domElement.addEventListener("mousedown", _0x332042 => {
  if (_0x332042.button === 2) {
    rmb = true;
    return;
  }
  if (_0x332042.button === 0 && locked) {
    const _0xee1905 = document.getElementById("settings-panel");
    if (_0xee1905 && _0xee1905.style.display !== "none") {
      for (const _0x87ec04 of _0xee1905.querySelectorAll("input[type=range]")) {
        if (_cursorOver(_0x87ec04)) {
          _sliderDrag = _0x87ec04;
          return;
        }
      }
    }
  }
});
document.addEventListener("mouseup", _0x2a1766 => {
  if (_0x2a1766.button === 2) {
    rmb = false;
  }
  if (_0x2a1766.button === 0) {
    _sliderDrag = null;
  }
});
document.addEventListener("mousemove", _0x8d08ca => {
  if (!locked) {
    return;
  }
  if (_sliderDrag) {
    cursorX = Math.max(0, Math.min(window.innerWidth, cursorX + _0x8d08ca.movementX));
    cursorY = Math.max(0, Math.min(window.innerHeight, cursorY + _0x8d08ca.movementY));
    cursorEl.style.transform = "translate(" + cursorX + "px, " + cursorY + "px)";
    const _0x453493 = parseFloat(_sliderDrag.max) - parseFloat(_sliderDrag.min);
    let _0x132703 = parseFloat(_sliderDrag.value) + _0x8d08ca.movementX * _0x453493 * 0.005;
    _0x132703 = Math.max(parseFloat(_sliderDrag.min), Math.min(parseFloat(_sliderDrag.max), _0x132703));
    _sliderDrag.value = _0x132703;
    _sliderDrag.dispatchEvent(new Event("input", {
      bubbles: true
    }));
    return;
  }
  if (shiftLock || rmb) {
    cam.yaw -= _0x8d08ca.movementX * CAM_H_SENS;
    cam.pitch = Math.max(cam.minPitch, Math.min(cam.maxPitch, cam.pitch + _0x8d08ca.movementY * CAM_V_SENS));
  } else {
    cursorX = Math.max(0, Math.min(window.innerWidth, cursorX + _0x8d08ca.movementX));
    cursorY = Math.max(0, Math.min(window.innerHeight, cursorY + _0x8d08ca.movementY));
    cursorEl.style.transform = "translate(" + cursorX + "px, " + cursorY + "px)";
  }
});
renderer.domElement.addEventListener("wheel", _0x1ca41c => {
  if (locked) {
    for (const _0x16c5ea of ["chat-messages", "lb-body"]) {
      const _0x5876b3 = document.getElementById(_0x16c5ea);
      if (!_0x5876b3) {
        continue;
      }
      const _0x1d2491 = _0x5876b3.getBoundingClientRect();
      if (cursorX >= _0x1d2491.left && cursorX <= _0x1d2491.right && cursorY >= _0x1d2491.top && cursorY <= _0x1d2491.bottom) {
        _0x5876b3.scrollTop += _0x1ca41c.deltaY;
        return;
      }
    }
  }
  cam.distance = Math.max(cam.minDist, Math.min(cam.maxDist, cam.distance + _0x1ca41c.deltaY * 0.015));
}, {
  passive: true
});
function lerpAngle(_0x18f35c, _0x24fbec, _0x42338f) {
  let _0x422eaf = _0x24fbec - _0x18f35c;
  _0x422eaf = (_0x422eaf % (Math.PI * 2) + Math.PI * 3) % (Math.PI * 2) - Math.PI;
  return _0x18f35c + _0x422eaf * _0x42338f;
}
function setRot(_0x25fe06, _0x177d35, _0x5bcee0, _0x4b18cc, _0x40b9d4) {
  if (!_0x25fe06) {
    return;
  }
  const _0x2b5ba7 = anim.rest[_0x25fe06.name]?.[_0x177d35] ?? 0;
  _0x25fe06.rotation[_0x177d35] = THREE.MathUtils.lerp(_0x25fe06.rotation[_0x177d35], _0x2b5ba7 + _0x5bcee0, Math.min(1, _0x4b18cc * _0x40b9d4));
}
function updateClimbAnimation(_0x46ead0, _0xf9a1fc) {
  anim.time += _0x46ead0;
  const _0x193f4e = anim.time;
  const _0x5b4080 = 10;
  const _0x3ea0d3 = anim.bones.Left_Leg;
  const _0x4b4361 = anim.bones.Right_Leg;
  const _0x1230f8 = anim.bones.Left_Arm;
  const _0x150d88 = anim.bones.Right_Arm;
  const _0xc8a198 = anim.bones.Torso;
  const _0x3dbff5 = anim.rest.Left_Arm?.py ?? 0;
  const _0x546d59 = anim.rest.Right_Arm?.py ?? 0;
  const _0x2cf74c = _0xf9a1fc ? Math.sin(_0x193f4e * 6) * 0.15 : 0;
  setRot(_0x1230f8, "x", -Math.PI * 0.75 + _0x2cf74c, _0x5b4080, _0x46ead0);
  setRot(_0x150d88, "x", -Math.PI * 0.75 - _0x2cf74c, _0x5b4080, _0x46ead0);
  setRot(_0x1230f8, "z", 0.35, _0x5b4080, _0x46ead0);
  setRot(_0x150d88, "z", -0.35, _0x5b4080, _0x46ead0);
  const _0x118c04 = _0xf9a1fc ? Math.sin(_0x193f4e * 6) * 0.3 : 0;
  setRot(_0x3ea0d3, "x", 0.3 + _0x118c04, _0x5b4080, _0x46ead0);
  setRot(_0x4b4361, "x", 0.3 - _0x118c04, _0x5b4080, _0x46ead0);
  setRot(_0xc8a198, "x", -0.15, _0x5b4080, _0x46ead0);
  setRot(_0xc8a198, "z", 0, _0x5b4080, _0x46ead0);
  if (_0x1230f8) {
    _0x1230f8.position.y = THREE.MathUtils.lerp(_0x1230f8.position.y, _0x3dbff5 + 0.5, Math.min(1, _0x5b4080 * _0x46ead0));
  }
  if (_0x150d88) {
    _0x150d88.position.y = THREE.MathUtils.lerp(_0x150d88.position.y, _0x546d59 + 0.5, Math.min(1, _0x5b4080 * _0x46ead0));
  }
}
function updateAnimations(_0xcac6ee, _0xb9c10) {
  anim.time += _0xcac6ee;
  const _0x400637 = anim.time;
  const _0x4e79e0 = 12;
  const _0x228eae = anim.bones.Left_Leg;
  const _0x146704 = anim.bones.Right_Leg;
  const _0x96fb58 = anim.bones.Left_Arm;
  const _0x1b7d81 = anim.bones.Right_Arm;
  const _0x6df159 = anim.bones.Torso;
  const _0x4c81b9 = anim.bones.Head;
  const _0x2a504e = anim.rest.Left_Arm?.py ?? 0;
  const _0x2835a8 = anim.rest.Right_Arm?.py ?? 0;
  if (!grounded) {
    setRot(_0x228eae, "x", 0, _0x4e79e0, _0xcac6ee);
    setRot(_0x146704, "x", 0, _0x4e79e0, _0xcac6ee);
    setRot(_0x96fb58, "x", -Math.PI, _0x4e79e0, _0xcac6ee);
    setRot(_0x1b7d81, "x", -Math.PI, _0x4e79e0, _0xcac6ee);
    setRot(_0x96fb58, "z", 0, _0x4e79e0, _0xcac6ee);
    setRot(_0x1b7d81, "z", 0, _0x4e79e0, _0xcac6ee);
    setRot(_0x6df159, "x", 0, _0x4e79e0, _0xcac6ee);
    if (_0x96fb58) {
      _0x96fb58.position.y = THREE.MathUtils.lerp(_0x96fb58.position.y, _0x2a504e - 0.75, Math.min(1, _0x4e79e0 * _0xcac6ee));
    }
    if (_0x1b7d81) {
      _0x1b7d81.position.y = THREE.MathUtils.lerp(_0x1b7d81.position.y, _0x2835a8 - 0.75, Math.min(1, _0x4e79e0 * _0xcac6ee));
    }
  } else if (_0xb9c10) {
    const _0x319957 = Math.sin(_0x400637 * 2.8 * Math.PI);
    setRot(_0x228eae, "x", _0x319957 * 1, _0x4e79e0, _0xcac6ee);
    setRot(_0x146704, "x", -_0x319957 * 1, _0x4e79e0, _0xcac6ee);
    setRot(_0x96fb58, "x", -_0x319957 * 0.8, _0x4e79e0, _0xcac6ee);
    setRot(_0x1b7d81, "x", _0x319957 * 0.8, _0x4e79e0, _0xcac6ee);
    setRot(_0x96fb58, "z", 0.05, _0x4e79e0, _0xcac6ee);
    setRot(_0x1b7d81, "z", -0.05, _0x4e79e0, _0xcac6ee);
    setRot(_0x6df159, "x", 0.03, _0x4e79e0, _0xcac6ee);
    setRot(_0x6df159, "z", 0, _0x4e79e0, _0xcac6ee);
    if (_0x96fb58) {
      _0x96fb58.position.y = THREE.MathUtils.lerp(_0x96fb58.position.y, _0x2a504e, Math.min(1, _0x4e79e0 * _0xcac6ee));
    }
    if (_0x1b7d81) {
      _0x1b7d81.position.y = THREE.MathUtils.lerp(_0x1b7d81.position.y, _0x2835a8, Math.min(1, _0x4e79e0 * _0xcac6ee));
    }
  } else {
    const _0x1753c0 = Math.sin(_0x400637 * 1.2) * 0.015;
    setRot(_0x228eae, "x", 0, _0x4e79e0, _0xcac6ee);
    setRot(_0x146704, "x", 0, _0x4e79e0, _0xcac6ee);
    setRot(_0x96fb58, "x", 0, _0x4e79e0, _0xcac6ee);
    setRot(_0x1b7d81, "x", 0, _0x4e79e0, _0xcac6ee);
    setRot(_0x96fb58, "z", 0.1 + _0x1753c0, _0x4e79e0, _0xcac6ee);
    setRot(_0x1b7d81, "z", -0.1 - _0x1753c0, _0x4e79e0, _0xcac6ee);
    setRot(_0x6df159, "x", _0x1753c0, _0x4e79e0, _0xcac6ee);
    setRot(_0x6df159, "z", 0, _0x4e79e0, _0xcac6ee);
    if (_0x96fb58) {
      _0x96fb58.position.y = THREE.MathUtils.lerp(_0x96fb58.position.y, _0x2a504e, Math.min(1, _0x4e79e0 * _0xcac6ee));
    }
    if (_0x1b7d81) {
      _0x1b7d81.position.y = THREE.MathUtils.lerp(_0x1b7d81.position.y, _0x2835a8, Math.min(1, _0x4e79e0 * _0xcac6ee));
    }
  }
}
function obbOverlap(_0x5b629e, _0x322cb8, _0x4b1b81, _0x2aa493, _0x557db0) {
  const _0x280c5c = Math.abs(_0x4b1b81);
  const _0x2744c8 = Math.abs(_0x2aa493);
  const _0x30a6d5 = (_0x557db0.minX + _0x557db0.maxX) * 0.5;
  const _0x139c51 = (_0x557db0.minZ + _0x557db0.maxZ) * 0.5;
  const _0x4db3b3 = (_0x557db0.maxX - _0x557db0.minX) * 0.5;
  const _0x135b75 = (_0x557db0.maxZ - _0x557db0.minZ) * 0.5;
  const _0x2aa326 = _0x30a6d5 - _0x5b629e;
  const _0x340106 = _0x139c51 - _0x322cb8;
  const _0x56061e = CHAR_HALF_W * _0x280c5c + CHAR_HALF_D * _0x2744c8 + _0x4db3b3 - Math.abs(_0x2aa326);
  if (_0x56061e <= 0) {
    return null;
  }
  const _0x2375e2 = CHAR_HALF_W * _0x2744c8 + CHAR_HALF_D * _0x280c5c + _0x135b75 - Math.abs(_0x340106);
  if (_0x2375e2 <= 0) {
    return null;
  }
  const _0x27a199 = _0x2aa326 * _0x4b1b81 - _0x340106 * _0x2aa493;
  const _0x189339 = CHAR_HALF_W + (_0x4db3b3 * _0x280c5c + _0x135b75 * _0x2744c8) - Math.abs(_0x27a199);
  if (_0x189339 <= 0) {
    return null;
  }
  const _0x5786cb = _0x2aa326 * _0x2aa493 + _0x340106 * _0x4b1b81;
  const _0x27b4e1 = CHAR_HALF_D + (_0x4db3b3 * _0x2744c8 + _0x135b75 * _0x280c5c) - Math.abs(_0x5786cb);
  if (_0x27b4e1 <= 0) {
    return null;
  }
  return {
    ov0: _0x56061e,
    ov1: _0x2375e2,
    ov2: _0x189339,
    ov3: _0x27b4e1,
    dx: _0x2aa326,
    dz: _0x340106,
    dp2: _0x27a199,
    dp3: _0x5786cb,
    co: _0x4b1b81,
    si: _0x2aa493
  };
}
function mtvOBBvsChar(_0x3c3175) {
  const _0x57794a = character.position.x;
  const _0x155f2a = character.position.y - CHAR_FOOT_OFFSET + CHAR_HEIGHT / 2;
  const _0x53f120 = character.position.z;
  const _0x298d82 = CHAR_HALF_W;
  const _0x172032 = CHAR_HEIGHT / 2;
  const _0x1e5d25 = CHAR_HALF_D;
  const _0x53e921 = _0x57794a - _0x3c3175.cx;
  const _0x44723f = _0x155f2a - _0x3c3175.cy;
  const _0x240a23 = _0x53f120 - _0x3c3175.cz;
  let _0x1d4e8d = Infinity;
  let _0x5732e6 = 0;
  let _0x571e82 = 0;
  let _0x8c0a4a = 0;
  function _0x586042(_0x586d53, _0x346c9e, _0x151c48) {
    const _0x21e6b2 = Math.sqrt(_0x586d53 * _0x586d53 + _0x346c9e * _0x346c9e + _0x151c48 * _0x151c48);
    if (_0x21e6b2 < 0.000001) {
      return true;
    }
    _0x586d53 /= _0x21e6b2;
    _0x346c9e /= _0x21e6b2;
    _0x151c48 /= _0x21e6b2;
    const _0x29cfd8 = _0x298d82 * Math.abs(_0x586d53) + _0x172032 * Math.abs(_0x346c9e) + _0x1e5d25 * Math.abs(_0x151c48);
    const _0x1f3876 = _0x3c3175.hx * Math.abs(_0x586d53 * _0x3c3175.ux + _0x346c9e * _0x3c3175.uy + _0x151c48 * _0x3c3175.uz) + _0x3c3175.hy * Math.abs(_0x586d53 * _0x3c3175.vx + _0x346c9e * _0x3c3175.vy + _0x151c48 * _0x3c3175.vz) + _0x3c3175.hz * Math.abs(_0x586d53 * _0x3c3175.wx + _0x346c9e * _0x3c3175.wy + _0x151c48 * _0x3c3175.wz);
    const _0x33157f = Math.abs(_0x53e921 * _0x586d53 + _0x44723f * _0x346c9e + _0x240a23 * _0x151c48);
    const _0x5ba14d = _0x29cfd8 + _0x1f3876 - _0x33157f;
    if (_0x5ba14d <= 0) {
      return false;
    }
    if (_0x5ba14d < _0x1d4e8d) {
      _0x1d4e8d = _0x5ba14d;
      _0x5732e6 = _0x586d53;
      _0x571e82 = _0x346c9e;
      _0x8c0a4a = _0x151c48;
    }
    return true;
  }
  if (!_0x586042(1, 0, 0)) {
    return null;
  }
  if (!_0x586042(0, 1, 0)) {
    return null;
  }
  if (!_0x586042(0, 0, 1)) {
    return null;
  }
  if (!_0x586042(_0x3c3175.ux, _0x3c3175.uy, _0x3c3175.uz)) {
    return null;
  }
  if (!_0x586042(_0x3c3175.vx, _0x3c3175.vy, _0x3c3175.vz)) {
    return null;
  }
  if (!_0x586042(_0x3c3175.wx, _0x3c3175.wy, _0x3c3175.wz)) {
    return null;
  }
  const _0x3c896a = [[1, 0, 0], [0, 1, 0], [0, 0, 1]];
  const _0x58ae05 = [[_0x3c3175.ux, _0x3c3175.uy, _0x3c3175.uz], [_0x3c3175.vx, _0x3c3175.vy, _0x3c3175.vz], [_0x3c3175.wx, _0x3c3175.wy, _0x3c3175.wz]];
  for (const [_0x5edc61, _0x403af2, _0xce699c] of _0x3c896a) {
    for (const [_0x12224d, _0xe5216f, _0x5aa4f9] of _0x58ae05) {
      if (!_0x586042(_0x403af2 * _0x5aa4f9 - _0xce699c * _0xe5216f, _0xce699c * _0x12224d - _0x5edc61 * _0x5aa4f9, _0x5edc61 * _0xe5216f - _0x403af2 * _0x12224d)) {
        return null;
      }
    }
  }
  if (_0x53e921 * _0x5732e6 + _0x44723f * _0x571e82 + _0x240a23 * _0x8c0a4a < 0) {
    _0x5732e6 = -_0x5732e6;
    _0x571e82 = -_0x571e82;
    _0x8c0a4a = -_0x8c0a4a;
  }
  return {
    nx: _0x5732e6,
    ny: _0x571e82,
    nz: _0x8c0a4a,
    depth: _0x1d4e8d
  };
}
function resolveOBBH(_0x2f39b1) {
  for (const _0x18526a of _0x2f39b1) {
    if (!_0x18526a.isOBB) {
      continue;
    }
    const _0x2f1873 = mtvOBBvsChar(_0x18526a);
    if (!_0x2f1873) {
      continue;
    }
    const {
      nx: _0x37cdb2,
      ny: _0x28f943,
      nz: _0x12050f,
      depth: _0x69f431
    } = _0x2f1873;
    const _0x43f12e = Math.abs(_0x28f943);
    const _0x46d46d = Math.sqrt(_0x37cdb2 * _0x37cdb2 + _0x12050f * _0x12050f);
    if (_0x46d46d <= _0x43f12e) {
      continue;
    }
    const _0x23eefb = character.position.y - CHAR_FOOT_OFFSET;
    const _0x563022 = _0x18526a.maxY - _0x23eefb;
    if (_0x563022 > 0 && _0x563022 <= STEP_HEIGHT && grounded && velY <= 0) {
      if (_0x18526a.maxY + CHAR_FOOT_OFFSET > stepUpTarget) {
        stepUpTarget = _0x18526a.maxY + CHAR_FOOT_OFFSET;
      }
      continue;
    }
    character.position.x += _0x37cdb2 * _0x69f431;
    character.position.z += _0x12050f * _0x69f431;
    pushedBlocks.add(_0x18526a);
  }
}
function resolveOBBV(_0x43bfb7) {
  for (const _0x41dbdd of _0x43bfb7) {
    if (!_0x41dbdd.isOBB) {
      continue;
    }
    if (pushedBlocks.has(_0x41dbdd)) {
      continue;
    }
    const _0x23b3a0 = mtvOBBvsChar(_0x41dbdd);
    if (!_0x23b3a0) {
      continue;
    }
    const {
      nx: _0x114f4e,
      ny: _0x357472,
      nz: _0x918dbf,
      depth: _0x3c6913
    } = _0x23b3a0;
    const _0x49d18c = Math.abs(_0x357472);
    const _0x489a40 = Math.sqrt(_0x114f4e * _0x114f4e + _0x918dbf * _0x918dbf);
    if (_0x489a40 > _0x49d18c) {
      continue;
    }
    const _0x3724f2 = _0x49d18c > 0.001 ? _0x3c6913 / _0x49d18c : _0x3c6913;
    if (_0x357472 > 0) {
      character.position.y += _0x3724f2;
      if (velY < 0) {
        velY = 0;
        grounded = true;
        extraVelX = 0;
        extraVelZ = 0;
      }
    } else {
      character.position.y -= _0x3724f2;
      if (velY > 0) {
        velY = 0;
      }
    }
  }
}
function resolveBlocksH(_0x2dfcab) {
  stepUpTarget = -Infinity;
  pushedBlocks.clear();
  const _0x523c3c = character.position.x;
  const _0x392341 = character.position.z;
  const _0x33f2d5 = character.rotation.y;
  const _0x4b6dff = Math.cos(_0x33f2d5);
  const _0x4cabe0 = Math.sin(_0x33f2d5);
  for (const _0x35c1e5 of _0x2dfcab) {
    if (_0x35c1e5.isOBB) {
      continue;
    }
    const _0x1a786d = character.position.y - CHAR_FOOT_OFFSET;
    if (_0x35c1e5.maxY <= _0x1a786d || _0x35c1e5.minY >= _0x1a786d + CHAR_HEIGHT) {
      continue;
    }
    const _0x27df86 = obbOverlap(_0x523c3c, _0x392341, _0x4b6dff, _0x4cabe0, _0x35c1e5);
    if (!_0x27df86) {
      continue;
    }
    const _0x1f3836 = _0x35c1e5.maxY - _0x1a786d;
    if (_0x1f3836 > 0 && _0x1f3836 <= STEP_HEIGHT && grounded && velY <= 0) {
      stepUpTarget = _0x35c1e5.maxY + CHAR_FOOT_OFFSET;
      continue;
    }
    const _0x296e3e = Math.max(_0x1a786d, _0x35c1e5.minY);
    const _0x12fe15 = Math.min(_0x1a786d + CHAR_HEIGHT, _0x35c1e5.maxY);
    if (_0x12fe15 - _0x296e3e < 0.02) {
      continue;
    }
    const {
      ov0: _0x4a48de,
      ov1: _0x355ee3,
      dx: _0x25e424,
      dz: _0x2d608b
    } = _0x27df86;
    if (_0x4a48de <= _0x355ee3) {
      character.position.x -= Math.sign(_0x25e424) * _0x4a48de;
    } else {
      character.position.z -= Math.sign(_0x2d608b) * _0x355ee3;
    }
    pushedBlocks.add(_0x35c1e5);
  }
}
function resolveBlocksV(_0x19400c) {
  const _0x13d0b7 = character.position.x;
  const _0x514fc6 = character.position.z;
  const _0x2979e1 = character.rotation.y;
  const _0x445ea7 = Math.cos(_0x2979e1);
  const _0x1b4552 = Math.sin(_0x2979e1);
  for (const _0x71db81 of _0x19400c) {
    if (_0x71db81.isOBB) {
      continue;
    }
    if (pushedBlocks.has(_0x71db81)) {
      continue;
    }
    const _0x3647a7 = character.position.y - CHAR_FOOT_OFFSET;
    if (!obbOverlap(_0x13d0b7, _0x514fc6, _0x445ea7, _0x1b4552, _0x71db81)) {
      continue;
    }
    const _0x146d4f = _0x71db81.maxY - _0x3647a7;
    const _0x5d795f = _0x3647a7 + CHAR_HEIGHT - _0x71db81.minY;
    if (_0x146d4f <= 0 || _0x5d795f <= 0) {
      continue;
    }
    if (_0x146d4f <= _0x5d795f) {
      if (stepUpTarget > -Infinity && Math.abs(_0x71db81.maxY + CHAR_FOOT_OFFSET - stepUpTarget) < 0.1) {
        velY = 0;
        grounded = true;
        extraVelX = 0;
        extraVelZ = 0;
      } else {
        character.position.y = _0x71db81.maxY + CHAR_FOOT_OFFSET;
        if (velY < 0) {
          velY = 0;
          grounded = true;
          extraVelX = 0;
          extraVelZ = 0;
        }
      }
    } else if (_0x3647a7 < _0x71db81.minY) {
      character.position.y = _0x71db81.minY - CHAR_HEIGHT + CHAR_FOOT_OFFSET;
      if (velY > 0) {
        velY = 0;
      }
    }
  }
}
function findClimbableBlock(_0x5e6066, _0x1b02fe, _0x32f08f, _0x1bdaee, _0x583cce) {
  if (climbBlock) {
    const _0x71daa1 = climbBlock;
    if (_0x71daa1.maxY - _0x71daa1.minY <= CLIMB_MAX_PART_H && _0x71daa1.maxY >= _0x32f08f - HANG_DEPTH - 0.1 && _0x71daa1.minY <= _0x32f08f + CHAR_HEIGHT) {
      const _0x3a033c = Math.max(_0x71daa1.minX, Math.min(_0x5e6066, _0x71daa1.maxX));
      const _0x58f11a = Math.max(_0x71daa1.minZ, Math.min(_0x1b02fe, _0x71daa1.maxZ));
      const _0x308e1c = _0x3a033c - _0x5e6066;
      const _0x3d734a = _0x58f11a - _0x1b02fe;
      const _0x2f39f8 = Math.sqrt(_0x308e1c * _0x308e1c + _0x3d734a * _0x3d734a);
      if (_0x2f39f8 <= CHAR_HALF_W + CLIMB_REACH + 0.4) {
        return _0x71daa1;
      }
    }
  }
  const _0x2c9ded = getNearbyColliders(_0x5e6066, _0x32f08f + CHAR_HEIGHT / 2, _0x1b02fe);
  let _0x17da20 = null;
  let _0xf7cff5 = Infinity;
  for (const _0x1b3f6b of _0x2c9ded) {
    if (_0x1b3f6b.maxY - _0x1b3f6b.minY > CLIMB_MAX_PART_H) {
      continue;
    }
    if (_0x1b3f6b.maxY < _0x32f08f - HANG_DEPTH - 0.1) {
      continue;
    }
    if (_0x1b3f6b.minY > _0x32f08f + CHAR_HEIGHT) {
      continue;
    }
    const _0x5d46cb = Math.max(_0x1b3f6b.minX, Math.min(_0x5e6066, _0x1b3f6b.maxX));
    const _0x12bf76 = Math.max(_0x1b3f6b.minZ, Math.min(_0x1b02fe, _0x1b3f6b.maxZ));
    const _0x587c5f = _0x5d46cb - _0x5e6066;
    const _0x14a440 = _0x12bf76 - _0x1b02fe;
    const _0x5ab4cf = Math.sqrt(_0x587c5f * _0x587c5f + _0x14a440 * _0x14a440);
    if (_0x5ab4cf > CHAR_HALF_W + CLIMB_REACH + 0.4) {
      continue;
    }
    if (_0x5ab4cf >= 0.01) {
      if (_0x587c5f / _0x5ab4cf * _0x1bdaee + _0x14a440 / _0x5ab4cf * _0x583cce < -0.5) {
        continue;
      }
    }
    const _0x876a49 = _0x5ab4cf + Math.abs(_0x1b3f6b.maxY - _0x32f08f) * 0.1;
    if (_0x876a49 < _0xf7cff5) {
      _0xf7cff5 = _0x876a49;
      _0x17da20 = _0x1b3f6b;
    }
  }
  return _0x17da20;
}
function findChainBlockBelow(_0x4828c7, _0x56bb12, _0x5b35f8, _0x68c110, _0x328e08) {
  const _0x3f60f6 = getNearbyColliders(_0x4828c7, _0x5b35f8, _0x56bb12);
  let _0x5b23df = null;
  let _0xd276d5 = -Infinity;
  for (const _0x2d0a68 of _0x3f60f6) {
    if (_0x2d0a68.maxY - _0x2d0a68.minY > CLIMB_MAX_PART_H) {
      continue;
    }
    if (_0x2d0a68.maxY >= _0x5b35f8 - 0.01) {
      continue;
    }
    if (_0x2d0a68.maxY < _0x5b35f8 - CLIMB_WINDOW) {
      continue;
    }
    const _0x4bb5ec = Math.max(_0x2d0a68.minX, Math.min(_0x4828c7, _0x2d0a68.maxX));
    const _0x388265 = Math.max(_0x2d0a68.minZ, Math.min(_0x56bb12, _0x2d0a68.maxZ));
    const _0x13b02e = _0x4bb5ec - _0x4828c7;
    const _0x737036 = _0x388265 - _0x56bb12;
    const _0x5da899 = Math.sqrt(_0x13b02e * _0x13b02e + _0x737036 * _0x737036);
    if (_0x5da899 > CHAR_HALF_W + CLIMB_REACH + 0.4) {
      continue;
    }
    if (_0x2d0a68.maxY > _0xd276d5) {
      _0x5b23df = _0x2d0a68;
      _0xd276d5 = _0x2d0a68.maxY;
    }
  }
  return _0x5b23df;
}
function findChainBlockAbove(_0x1d39c0, _0x3e259e, _0x179033, _0x1c88bd, _0xef44fb) {
  const _0x2f0386 = getNearbyColliders(_0x1d39c0, _0x179033, _0x3e259e);
  for (const _0x4ac926 of _0x2f0386) {
    if (_0x4ac926.maxY - _0x4ac926.minY > CLIMB_MAX_PART_H) {
      continue;
    }
    if (_0x4ac926.maxY <= _0x179033 + 0.01 || _0x4ac926.maxY > _0x179033 + CLIMB_WINDOW) {
      continue;
    }
    const _0x4d150c = (_0x4ac926.minX + _0x4ac926.maxX) * 0.5 - _0x1d39c0;
    const _0x4d2c51 = (_0x4ac926.minZ + _0x4ac926.maxZ) * 0.5 - _0x3e259e;
    const _0x53b776 = Math.sqrt(_0x4d150c * _0x4d150c + _0x4d2c51 * _0x4d2c51);
    if (_0x53b776 > 0.01 && _0x4d150c / _0x53b776 * _0x1c88bd + _0x4d2c51 / _0x53b776 * _0xef44fb < 0.4) {
      continue;
    }
    return _0x4ac926;
  }
  return null;
}
function tryLedgeGrab(_0x1206e6) {
  if (climbCooldown > 0 || climbState !== "none" || grounded || velY < CLIMB_FALL_CUTOFF) {
    return;
  }
  if ((keys.KeyS || keys.ArrowDown) && !keys.KeyW && !keys.ArrowUp) {
    return;
  }
  const _0xfb11c5 = character.position.y - CHAR_FOOT_OFFSET;
  const _0x4b5654 = character.position.x;
  const _0x1c0217 = character.position.z;
  const _0x26b9de = Math.sin(character.rotation.y);
  const _0x5dd420 = Math.cos(character.rotation.y);
  let _0x290f4f = null;
  let _0x3ac31d = 0;
  let _0x2de1c1 = 0;
  let _0x8fdb35 = Infinity;
  for (const _0x832ef0 of _0x1206e6) {
    if (_0x832ef0.maxY - _0x832ef0.minY > CLIMB_MAX_PART_H) {
      continue;
    }
    const _0x2747a7 = _0x832ef0.maxY - _0xfb11c5;
    if (_0x2747a7 < 0.3 || _0x2747a7 > CLIMB_WINDOW) {
      continue;
    }
    if (_0x832ef0.minY > _0xfb11c5 + CHAR_HEIGHT) {
      continue;
    }
    const _0x47371a = Math.min(_0x4b5654 + CHAR_HALF_W + CLIMB_REACH, _0x832ef0.maxX) - Math.max(_0x4b5654 - CHAR_HALF_W - CLIMB_REACH, _0x832ef0.minX);
    const _0x18e987 = Math.min(_0x1c0217 + CHAR_HALF_D + CLIMB_REACH, _0x832ef0.maxZ) - Math.max(_0x1c0217 - CHAR_HALF_D - CLIMB_REACH, _0x832ef0.minZ);
    if (_0x47371a <= 0 || _0x18e987 <= 0) {
      continue;
    }
    const _0x7f08a4 = Math.max(_0x832ef0.minX, Math.min(_0x4b5654, _0x832ef0.maxX));
    const _0x5a4084 = Math.max(_0x832ef0.minZ, Math.min(_0x1c0217, _0x832ef0.maxZ));
    let _0x1eb753 = _0x7f08a4 - _0x4b5654;
    let _0x96ae1d = _0x5a4084 - _0x1c0217;
    const _0x88a26c = Math.sqrt(_0x1eb753 * _0x1eb753 + _0x96ae1d * _0x96ae1d);
    if (_0x88a26c < 0.01) {
      _0x1eb753 = _0x26b9de;
      _0x96ae1d = _0x5dd420;
    } else {
      _0x1eb753 /= _0x88a26c;
      _0x96ae1d /= _0x88a26c;
      if (_0x1eb753 * _0x26b9de + _0x96ae1d * _0x5dd420 < -0.9) {
        continue;
      }
    }
    if (_0x88a26c < _0x8fdb35) {
      _0x8fdb35 = _0x88a26c;
      _0x290f4f = _0x832ef0;
      _0x3ac31d = _0x1eb753;
      _0x2de1c1 = _0x96ae1d;
    }
  }
  if (!_0x290f4f) {
    return;
  }
  climbLedgeY = _0x290f4f.maxY;
  climbBlock = _0x290f4f;
  climbFwdX = _0x3ac31d;
  climbFwdZ = _0x2de1c1;
  climbState = "hanging";
  velY = 0;
}
function update(_0x4cca10) {
  if (!character || !_worldBuilt) {
    return;
  }
  if (keys.KeyI) {
    cam.distance = Math.max(cam.minDist, cam.distance - CAM_KEY_ZOOM_SPEED * _0x4cca10);
  }
  if (keys.KeyO) {
    cam.distance = Math.min(cam.maxDist, cam.distance + CAM_KEY_ZOOM_SPEED * _0x4cca10);
  }
  if (climbState === "hanging") {
    const _0x12d75f = character.position.x;
    const _0x5e2aa1 = character.position.z;
    let _0x4aad99 = character.position.y - CHAR_FOOT_OFFSET;
    const _0x1db6db = findClimbableBlock(_0x12d75f, _0x5e2aa1, _0x4aad99, climbFwdX, climbFwdZ);
    if (!_0x1db6db) {
      climbState = "none";
      climbCooldown = 0.25;
      updateClimbAnimation(_0x4cca10);
      return;
    }
    climbBlock = _0x1db6db;
    climbLedgeY = _0x1db6db.maxY;
    if (shiftLock) {
      const _0x5b0673 = Math.atan2(climbFwdX, climbFwdZ);
      const _0x13cd83 = cam.yaw + Math.PI;
      const _0x30803b = ((_0x13cd83 - _0x5b0673) % (Math.PI * 2) + Math.PI * 3) % (Math.PI * 2) - Math.PI;
      if (Math.abs(_0x30803b) > Math.PI / 4) {
        climbState = "none";
        climbCooldown = 0.25;
        velY = 0;
        updateClimbAnimation(_0x4cca10);
        return;
      }
      character.rotation.y = cam.yaw + Math.PI;
    } else {
      const _0x46b88f = Math.atan2(climbFwdX, climbFwdZ);
      character.rotation.y = lerpAngle(character.rotation.y, _0x46b88f, Math.min(1, ROT_SPEED * _0x4cca10));
    }
    if (jumpBuffer > 0) {
      velY = CLIMB_JUMP_UP;
      extraVelX = -climbFwdX * CLIMB_JUMP_BACK_V;
      extraVelZ = -climbFwdZ * CLIMB_JUMP_BACK_V;
      climbState = "none";
      climbCooldown = 0;
      jumpBuffer = 0;
      updateClimbAnimation(_0x4cca10);
      return;
    }
    const _0x51cadd = !!keys.KeyW || !!keys.ArrowUp;
    const _0x106f66 = !!keys.KeyS || !!keys.ArrowDown;
    const _0x251c86 = (_0x51cadd ? 1 : 0) - (_0x106f66 ? 1 : 0);
    const _0x4b8749 = _0x251c86 !== 0;
    if (_0x251c86 < -0.1 && _0x4aad99 <= G + 0.15) {
      character.position.y = CHAR_STAND_Y;
      climbState = "none";
      climbCooldown = 0;
      velY = 0;
      updateClimbAnimation(_0x4cca10);
      return;
    }
    velY = 0;
    character.position.y += _0x251c86 * CLIMB_RISE_SPEED * _0x4cca10;
    _0x4aad99 = character.position.y - CHAR_FOOT_OFFSET;
    if (_0x251c86 < 0 && _0x4aad99 < climbLedgeY - HANG_DEPTH) {
      const _0x1beafe = findChainBlockBelow(character.position.x, character.position.z, climbLedgeY, climbFwdX, climbFwdZ);
      if (_0x1beafe) {
        climbBlock = _0x1beafe;
        climbLedgeY = _0x1beafe.maxY;
      } else {
        climbState = "none";
        climbCooldown = 0.1;
        velY = -2;
        updateClimbAnimation(_0x4cca10);
        return;
      }
    }
    if (_0x4aad99 < G) {
      character.position.y = CHAR_STAND_Y;
      climbState = "none";
      climbCooldown = 0;
      velY = 0;
      updateClimbAnimation(_0x4cca10);
      return;
    }
    _0x4aad99 = character.position.y - CHAR_FOOT_OFFSET;
    if (_0x4aad99 >= climbLedgeY) {
      const _0x5b7c97 = findChainBlockAbove(character.position.x, character.position.z, climbLedgeY, climbFwdX, climbFwdZ);
      if (_0x5b7c97) {
        climbBlock = _0x5b7c97;
        climbLedgeY = _0x5b7c97.maxY;
      } else if (_0x251c86 > 0.3) {
        character.position.x += climbFwdX * 0.4;
        character.position.z += climbFwdZ * 0.4;
        climbState = "none";
        velY = 2;
        updateClimbAnimation(_0x4cca10);
        return;
      } else {
        character.position.y = climbLedgeY + CHAR_FOOT_OFFSET;
      }
    }
    if (!_0x4b8749) {
      const _0x2bea94 = climbLedgeY - HANG_DEPTH + CHAR_FOOT_OFFSET;
      const _0x5f1ae8 = !findChainBlockAbove(character.position.x, character.position.z, climbLedgeY, climbFwdX, climbFwdZ);
      if (_0x5f1ae8 && character.position.y > _0x2bea94) {
        const _0x7cae6 = Math.min(CLIMB_RISE_SPEED * 2 * _0x4cca10, character.position.y - _0x2bea94);
        character.position.y -= _0x7cae6;
      }
    }
    updateClimbAnimation(_0x4cca10, _0x4b8749);
    return;
  }
  const _0x481020 = new THREE.Vector3();
  if (keys.KeyW || keys.ArrowUp) {
    _0x481020.z -= 1;
  }
  if (keys.KeyS || keys.ArrowDown) {
    _0x481020.z += 1;
  }
  if (keys.KeyA || keys.ArrowLeft) {
    _0x481020.x -= 1;
  }
  if (keys.KeyD || keys.ArrowRight) {
    _0x481020.x += 1;
  }
  const _0x5dbb03 = _0x481020.lengthSq() > 0;
  let _0x329862 = 0;
  let _0x4c6b85 = 0;
  if (_0x5dbb03) {
    _0x481020.normalize();
    const _0x18333d = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), cam.yaw);
    _0x481020.applyQuaternion(_0x18333d);
    _0x329862 = _0x481020.x * WALK_SPEED;
    _0x4c6b85 = _0x481020.z * WALK_SPEED;
    if (!shiftLock) {
      const _0x1eba11 = Math.atan2(_0x481020.x, _0x481020.z);
      character.rotation.y = lerpAngle(character.rotation.y, _0x1eba11, Math.min(1, ROT_SPEED * _0x4cca10));
    }
  }
  _0x329862 += extraVelX;
  _0x4c6b85 += extraVelZ;
  const _0x40afce = _0x329862 * _0x329862 + _0x4c6b85 * _0x4c6b85;
  if (_0x40afce > WALK_SPEED * WALK_SPEED) {
    const _0x2802e7 = WALK_SPEED / Math.sqrt(_0x40afce);
    _0x329862 *= _0x2802e7;
    _0x4c6b85 *= _0x2802e7;
  }
  {
    const _0x40b230 = character.position.y - CHAR_FOOT_OFFSET;
    const _0x182800 = Math.abs(Math.cos(character.rotation.y));
    const _0x30ccc9 = Math.abs(Math.sin(character.rotation.y));
    const _0x2cb260 = CHAR_HALF_W * _0x182800 + CHAR_HALF_D * _0x30ccc9;
    const _0x4ad473 = CHAR_HALF_W * _0x30ccc9 + CHAR_HALF_D * _0x182800;
    const _0x30ac47 = getNearbyColliders(character.position.x, character.position.y, character.position.z);
    let _0xa8fa4e = _0x329862 * _0x4cca10;
    for (const _0x1f9ed0 of _0x30ac47) {
      if (_0x1f9ed0.maxY <= _0x40b230 + 0.05 || _0x1f9ed0.minY >= _0x40b230 + CHAR_HEIGHT) {
        continue;
      }
      const _0x2c847b = _0x1f9ed0.maxY - _0x40b230;
      if (_0x2c847b > 0 && _0x2c847b <= STEP_HEIGHT && grounded && velY <= 0) {
        continue;
      }
      if (character.position.z + _0x4ad473 <= _0x1f9ed0.minZ || character.position.z - _0x4ad473 >= _0x1f9ed0.maxZ) {
        continue;
      }
      if (_0xa8fa4e > 0) {
        const _0x2918fe = character.position.x + _0x2cb260;
        if (_0x2918fe > _0x1f9ed0.minX) {
          continue;
        }
        const _0x5f2f64 = _0x1f9ed0.minX - _0x2918fe;
        if (_0x5f2f64 < _0xa8fa4e) {
          _0xa8fa4e = Math.max(0, _0x5f2f64);
        }
      } else if (_0xa8fa4e < 0) {
        const _0x3d16b3 = character.position.x - _0x2cb260;
        if (_0x3d16b3 < _0x1f9ed0.maxX) {
          continue;
        }
        const _0x432c03 = _0x1f9ed0.maxX - _0x3d16b3;
        if (_0x432c03 > _0xa8fa4e) {
          _0xa8fa4e = Math.min(0, _0x432c03);
        }
      }
    }
    character.position.x += _0xa8fa4e;
    let _0x5354a5 = _0x4c6b85 * _0x4cca10;
    for (const _0x165f19 of _0x30ac47) {
      if (_0x165f19.maxY <= _0x40b230 + 0.05 || _0x165f19.minY >= _0x40b230 + CHAR_HEIGHT) {
        continue;
      }
      const _0x20edf2 = _0x165f19.maxY - _0x40b230;
      if (_0x20edf2 > 0 && _0x20edf2 <= STEP_HEIGHT && grounded && velY <= 0) {
        continue;
      }
      if (character.position.x + _0x2cb260 <= _0x165f19.minX || character.position.x - _0x2cb260 >= _0x165f19.maxX) {
        continue;
      }
      if (_0x5354a5 > 0) {
        const _0x11dc27 = character.position.z + _0x4ad473;
        if (_0x11dc27 > _0x165f19.minZ) {
          continue;
        }
        const _0x10cb12 = _0x165f19.minZ - _0x11dc27;
        if (_0x10cb12 < _0x5354a5) {
          _0x5354a5 = Math.max(0, _0x10cb12);
        }
      } else if (_0x5354a5 < 0) {
        const _0x15d206 = character.position.z - _0x4ad473;
        if (_0x15d206 < _0x165f19.maxZ) {
          continue;
        }
        const _0x2f7c8c = _0x165f19.maxZ - _0x15d206;
        if (_0x2f7c8c > _0x5354a5) {
          _0x5354a5 = Math.min(0, _0x2f7c8c);
        }
      }
    }
    character.position.z += _0x5354a5;
  }
  if (extraVelX !== 0 || extraVelZ !== 0) {
    const _0x195fcf = Math.max(0, 1 - _0x4cca10 * 2.5);
    extraVelX *= _0x195fcf;
    extraVelZ *= _0x195fcf;
    if (Math.abs(extraVelX) < 0.3) {
      extraVelX = 0;
    }
    if (Math.abs(extraVelZ) < 0.3) {
      extraVelZ = 0;
    }
  }
  if (shiftLock) {
    character.rotation.y = cam.yaw + Math.PI;
  }
  climbCooldown = Math.max(0, climbCooldown - _0x4cca10);
  const _0x345805 = getNearbyColliders(character.position.x, character.position.y, character.position.z);
  resolveBlocksH(_0x345805);
  resolveOBBH(_0x345805);
  tryLedgeGrab(_0x345805);
  if (stepUpTarget > character.position.y) {
    const _0x416231 = Math.min(stepUpTarget - character.position.y, STEP_CLIMB_SPEED * _0x4cca10);
    character.position.y += _0x416231;
    velY = 0;
    grounded = true;
  }
  if (grounded) {
    coyoteTimer = COYOTE_TIME;
  } else {
    coyoteTimer = Math.max(0, coyoteTimer - _0x4cca10);
  }
  if (keys.Space) {
    jumpBuffer = JUMP_BUFFER;
  }
  jumpBuffer = Math.max(0, jumpBuffer - _0x4cca10);
  velY += GRAVITY * _0x4cca10;
  character.position.y += velY * _0x4cca10;
  grounded = false;
  if (character.position.y <= CHAR_STAND_Y) {
    character.position.y = CHAR_STAND_Y;
    velY = 0;
    grounded = true;
    extraVelX = 0;
    extraVelZ = 0;
  }
  resolveBlocksV(_0x345805);
  resolveOBBV(_0x345805);
  if (jumpBuffer > 0 && (grounded || coyoteTimer > 0)) {
    velY = JUMP_POWER;
    grounded = false;
    coyoteTimer = 0;
    jumpBuffer = 0;
  }
  updateAnimations(_0x4cca10, _0x5dbb03);
}
function updateCamera() {
  if (!character) {
    return;
  }
  const _0x289dc6 = Math.sin(cam.yaw);
  const _0x3b681c = Math.cos(cam.yaw);
  const _0x16b343 = Math.sin(cam.pitch);
  const _0x15a144 = Math.cos(cam.pitch);
  const _0x387198 = new THREE.Vector3(character.position.x, character.position.y + CAM_PIVOT_Y, character.position.z);
  if (shiftLock) {
    _0x387198.x += _0x3b681c * SHIFT_LOCK_OFFSET;
    _0x387198.z += -_0x289dc6 * SHIFT_LOCK_OFFSET;
  }
  camera.position.set(_0x387198.x + cam.distance * _0x15a144 * _0x289dc6, _0x387198.y + cam.distance * _0x16b343, _0x387198.z + cam.distance * _0x15a144 * _0x3b681c);
  camera.lookAt(_0x387198);
}
let lastTime = performance.now();
function loop(_0x1db769) {
  requestAnimationFrame(loop);
  const _0x1c1a4a = Math.min((_0x1db769 - lastTime) / 1000, 0.1);
  lastTime = _0x1db769;
  update(_0x1c1a4a);
  updateCamera();
  if (charDebugMesh && character) {
    const _0x3e3089 = character.position.y - CHAR_FOOT_OFFSET;
    charDebugMesh.position.set(character.position.x, _0x3e3089 + CHAR_HEIGHT / 2, character.position.z);
    charDebugMesh.rotation.y = character.rotation.y;
  }
  updateDebugMeshes();
  window._mpUpdate?.(_0x1c1a4a);
  window._vortexUpdate?.(_0x1c1a4a);
  renderer.render(scene, camera);
}
const DEG2RAD = Math.PI / 180;
async function loadMap(_0x2cb592, _0x832d44 = 0, _0x1f8af7 = 0, _0x49a347 = 0) {
  const _0x419d51 = await fetch(_0x2cb592).then(_0x279a9a => _0x279a9a.json());
  const _0x104910 = _0x419d51.filter(_0x43f901 => _0x43f901.Type === "Part" && _0x43f901.Shape === "Block");
  if (!_0x104910.length) {
    return;
  }
  let _0x12b318 = Infinity;
  let _0xe47c8b = Infinity;
  let _0xabade8 = Infinity;
  let _0x2d9afe = -Infinity;
  let _0x484146 = -Infinity;
  let _0x2edf2e = -Infinity;
  for (const _0x3e2956 of _0x104910) {
    const [_0xc860db, _0xa81a72, _0xbb36d9] = _0x3e2956.Position;
    _0x12b318 = Math.min(_0x12b318, _0xc860db);
    _0x2d9afe = Math.max(_0x2d9afe, _0xc860db);
    _0xe47c8b = Math.min(_0xe47c8b, _0xa81a72);
    _0x484146 = Math.max(_0x484146, _0xa81a72);
    _0xabade8 = Math.min(_0xabade8, _0xbb36d9);
    _0x2edf2e = Math.max(_0x2edf2e, _0xbb36d9);
  }
  const _0x1049dc = _0x832d44 - (_0x12b318 + _0x2d9afe) / 2;
  const _0x6311ef = _0x1f8af7 - (_0xe47c8b + _0x484146) / 2;
  const _0x33b3de = _0x49a347 - (_0xabade8 + _0x2edf2e) / 2;
  for (const _0x27130a of _0x104910) {
    const [_0x6ca462, _0x4e12a3, _0x4f0f9f] = _0x27130a.Size;
    const [_0x5bc625, _0x5b824e, _0x2d3dcd] = _0x27130a.Position;
    const [_0xcbbd34, _0x34ebd4, _0x559b3f] = _0x27130a.Rotation;
    let _0x563b34;
    if (typeof _0x27130a.Color === "string") {
      _0x563b34 = parseInt(_0x27130a.Color, 16);
    } else if (Array.isArray(_0x27130a.Color)) {
      const [_0x1e28cc, _0x911f31, _0xf4c571] = _0x27130a.Color;
      _0x563b34 = Math.round(_0x1e28cc * 255) << 16 | Math.round(_0x911f31 * 255) << 8 | Math.round(_0xf4c571 * 255);
    } else {
      _0x563b34 = Number(_0x27130a.Color);
    }
    addStud(_0x6ca462, _0x4e12a3, _0x4f0f9f, _0x563b34, _0x5bc625 + _0x1049dc, _0x5b824e - _0x4e12a3 / 2 + _0x6311ef, _0x2d3dcd + _0x33b3de, _0xcbbd34 * DEG2RAD, _0x34ebd4 * DEG2RAD, _0x559b3f * DEG2RAD);
  }
  if (window._vortex.finishWorld) {
    window._vortex.finishWorld();
  }
}
window._vortex = {
  finishWorld: () => {
    requestAnimationFrame(() => {
      if (window._vortex && window._vortex.scene) {
        scene.traverse(_0xb14d0 => {
          if (_0xb14d0.isMesh) {
            _0xb14d0._tmpFrustum = _0xb14d0.frustumCulled;
            _0xb14d0.frustumCulled = false;
          }
        });
        renderer.compile(scene, camera);
        scene.traverse(_0x41c93d => {
          if (_0x41c93d.isMesh) {
            _0x41c93d.frustumCulled = _0x41c93d._tmpFrustum !== undefined ? _0x41c93d._tmpFrustum : true;
          }
        });
      }
      _worldBuilt = true;
      setTimeout(() => {
        _loadingScreen.classList.add("hidden");
      }, 100);
    });
  },
  scene: scene,
  getCharacter: () => character,
  getGrounded: () => grounded,
  getVelY: () => velY,
  getClimbState: () => climbState,
  getCharFootOffset: () => CHAR_FOOT_OFFSET,
  getCharHeight: () => CHAR_HEIGHT,
  getAnimRest: () => anim.rest,
  keys: keys,
  setSens(_0x8be71c) {
    CAM_H_SENS = Math.PI * 0.002 * _0x8be71c;
    CAM_V_SENS = Math.PI * 0.0015 * _0x8be71c;
  },
  requestLock() {
    renderer.domElement.requestPointerLock();
  },
  loadMap: loadMap,
  getCamera: () => camera,
  getCharBubbleBase: () => character ? character.position.y + CHAR_HEIGHT - CHAR_FOOT_OFFSET + 0.4 : 0,
  setSpawn(_0x28cd8d, _0x2f4687, _0x257d0a, _0x4d882b = Math.PI) {
    _spawnPoint = {
      x: _0x28cd8d,
      y: _0x2f4687,
      z: _0x257d0a,
      ry: _0x4d882b
    };
    if (character) {
      character.position.set(_0x28cd8d, _0x2f4687 + CHAR_FOOT_OFFSET, _0x257d0a);
      character.rotation.y = _0x4d882b;
    }
  },
  applyShirt(_0x37eb44) {
    _applyShirtToMesh(_shirtMesh, _0x37eb44);
  },
  applyShirtToMesh(_0x5ae92a, _0x63f9d0) {
    _applyShirtToMesh(_0x5ae92a, _0x63f9d0);
  },
  buildShirtOverlay(_0x4e8923) {
    return _buildShirtOverlay(_0x4e8923);
  },
  cursorOver: _cursorOver
};
requestAnimationFrame(loop);