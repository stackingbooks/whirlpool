(function () {
  const _0x554d07 = ["#1a1a1a", "#2563EB", "#16A34A", "#9333EA", "#D97706", "#DC2626", "#0891B2"];
  function _0x25ffac(_0x55f99c) {
    let _0x3dd9e8 = 0;
    for (const _0x47742f of _0x55f99c) {
      _0x3dd9e8 = _0x3dd9e8 * 31 + _0x47742f.charCodeAt(0) & 65535;
    }
    return parseInt(_0x554d07[_0x3dd9e8 % _0x554d07.length].slice(1), 16);
  }
  function _0x801581(_0x19c108) {
    return _0x19c108.isBone || _0x19c108.type === "Bone";
  }
  function _0x48aa48() {
    const _0x5583d7 = _vortex.getCharacter();
    if (!_0x5583d7) {
      return null;
    }
    const _0x229ec5 = _0x5583d7.clone(true);
    const _0x313404 = [];
    _0x229ec5.traverse(_0x14929e => {
      if (_0x14929e.name === "ShirtOverlay") {
        _0x313404.push(_0x14929e);
      }
    });
    _0x313404.forEach(_0x51fbd4 => _0x51fbd4.parent?.remove(_0x51fbd4));
    const _0x261bc3 = {};
    const _0x1582c2 = {};
    _0x5583d7.traverse(_0x579500 => {
      if (_0x801581(_0x579500)) {
        _0x261bc3[_0x579500.name] = _0x579500;
      }
    });
    _0x229ec5.traverse(_0x2c9072 => {
      if (_0x801581(_0x2c9072)) {
        _0x1582c2[_0x2c9072.name] = _0x2c9072;
      }
    });
    const _0xdef554 = [];
    const _0x2610c9 = [];
    _0x5583d7.traverse(_0x502e84 => {
      if (_0x502e84.isSkinnedMesh) {
        _0xdef554.push(_0x502e84);
      }
    });
    _0x229ec5.traverse(_0x482bc5 => {
      if (_0x482bc5.isSkinnedMesh) {
        _0x2610c9.push(_0x482bc5);
      }
    });
    _0xdef554.forEach((_0x26fdd9, _0x10afeb) => {
      const _0x21af6a = _0x2610c9[_0x10afeb];
      if (!_0x21af6a) {
        return;
      }
      const _0x4d3db0 = _0x26fdd9.skeleton.bones.map(_0x42e387 => _0x1582c2[_0x42e387.name] || _0x42e387);
      _0x21af6a.skeleton = new THREE.Skeleton(_0x4d3db0, _0x26fdd9.skeleton.boneInverses.map(_0x26817d => _0x26817d.clone()));
      _0x21af6a.bind(_0x21af6a.skeleton, _0x26fdd9.bindMatrix.clone());
    });
    const _0x36c160 = _vortex.getAnimRest();
    _0x229ec5.traverse(_0x468ee7 => {
      if (!_0x801581(_0x468ee7) || !_0x36c160[_0x468ee7.name]) {
        return;
      }
      const _0x5b6c12 = _0x36c160[_0x468ee7.name];
      _0x468ee7.rotation.set(_0x5b6c12.x, _0x5b6c12.y, _0x5b6c12.z);
      _0x468ee7.position.y = _0x5b6c12.py;
    });
    _0x229ec5.rotation.set(0, Math.PI, 0);
    _0x229ec5.traverse(_0x41b257 => {
      if (_0x41b257.isMesh) {
        _0x41b257.castShadow = true;
      }
    });
    _0x229ec5.visible = false;
    _vortex.scene.add(_0x229ec5);
    return _0x229ec5;
  }
  function _0x4d1b5d(_0x413c9c) {
    const _0x44895c = document.createElement("canvas");
    _0x44895c.width = 512;
    _0x44895c.height = 80;
    const _0x53ccad = _0x44895c.getContext("2d");
    _0x53ccad.font = "bold 44px system-ui,sans-serif";
    _0x53ccad.textAlign = "center";
    _0x53ccad.strokeStyle = "rgba(0,0,0,0.9)";
    _0x53ccad.lineWidth = 6;
    _0x53ccad.strokeText(_0x413c9c, 256, 58);
    _0x53ccad.fillStyle = "#fff";
    _0x53ccad.fillText(_0x413c9c, 256, 58);
    const _0x455840 = new THREE.CanvasTexture(_0x44895c);
    const _0x5a6825 = new THREE.Sprite(new THREE.SpriteMaterial({
      map: _0x455840,
      depthTest: false
    }));
    _0x5a6825.scale.set(4, 0.625, 1);
    return _0x5a6825;
  }
  function _0x5b1a66(_0x2d529a, _0x10fc9b) {
    const _0x2f1bc7 = _0x48aa48();
    if (!_0x2f1bc7) {
      return null;
    }
    const _0x47ff0e = _vortex.getCharFootOffset();
    const _0x528bfc = _vortex.getCharHeight();
    const _0x47c9e0 = _0x4d1b5d(_0x2d529a);
    _0x47c9e0.position.y = _0x528bfc - _0x47ff0e + 1.4;
    _0x2f1bc7.add(_0x47c9e0);
    const _0x1fe36e = {};
    _0x2f1bc7.traverse(_0x1bed52 => {
      if (_0x801581(_0x1bed52)) {
        _0x1fe36e[_0x1bed52.name] = _0x1bed52;
      }
    });
    const _0x101d79 = _vortex.getAnimRest();
    const _0x5605ad = _vortex.buildShirtOverlay(_0x2f1bc7);
    if (_0x5605ad && _0x10fc9b) {
      _vortex.applyShirtToMesh(_0x5605ad, _0x10fc9b);
    }
    return {
      grp: _0x2f1bc7,
      bones: _0x1fe36e,
      rest: _0x101d79,
      shirtMesh: _0x5605ad
    };
  }
  function _0x3e9aa3(_0x50edd5, _0x3cbde6) {
    if (!_0x50edd5?.meshes?.shirtMesh) {
      return;
    }
    _vortex.applyShirtToMesh(_0x50edd5.meshes.shirtMesh, _0x3cbde6);
  }
  function _0x36ece4(_0x32ed3a) {
    if (!_0x32ed3a) {
      return;
    }
    _vortex.scene.remove(_0x32ed3a.grp);
    if (_0x32ed3a.shirtMesh) {
      _0x32ed3a.shirtMesh.geometry?.dispose();
      _0x32ed3a.shirtMesh.material?.map?.dispose();
      _0x32ed3a.shirtMesh.material?.dispose();
    }
    _0x32ed3a.grp.traverse(_0x3d17d7 => {
      if (_0x3d17d7.isSprite) {
        _0x3d17d7.material?.map?.dispose();
        _0x3d17d7.material?.dispose();
      }
    });
  }
  function _0x265178(_0x2cb1be, _0x1eff13, _0x3d524c, _0x4727d1, _0xcbbf71, _0x258f75, _0x5da893) {
    const _0x2210d3 = _0x2cb1be[_0x3d524c];
    if (!_0x2210d3) {
      return;
    }
    const _0x3f5fb3 = _0x1eff13[_0x3d524c]?.[_0x4727d1] ?? 0;
    _0x2210d3.rotation[_0x4727d1] = THREE.MathUtils.lerp(_0x2210d3.rotation[_0x4727d1], _0x3f5fb3 + _0xcbbf71, Math.min(1, _0x258f75 * _0x5da893));
  }
  function _0x1d73ae(_0x2beb31, _0x250dcd, _0x434646, _0x378b94, _0xdfed07, _0x4bc3be) {
    const _0xb3f994 = _0x2beb31[_0x434646];
    if (!_0xb3f994) {
      return;
    }
    const _0x5657b0 = _0x250dcd[_0x434646]?.py ?? 0;
    _0xb3f994.position.y = THREE.MathUtils.lerp(_0xb3f994.position.y, _0x5657b0 + _0x378b94, Math.min(1, _0xdfed07 * _0x4bc3be));
  }
  function _0x177f99(_0x672114, _0x28ab3d) {
    const {
      bones: _0x1988f7,
      rest: _0x197e0b
    } = _0x672114.meshes;
    const _0x11fba5 = 12;
    _0x672114.animTime += _0x28ab3d;
    const _0x5161de = _0x672114.animTime;
    if (_0x672114.anim === "climb") {
      const _0x398ecf = Math.sin(_0x5161de * 6) * 0.15;
      const _0x3a9bcd = Math.sin(_0x5161de * 6) * 0.3;
      _0x265178(_0x1988f7, _0x197e0b, "Left_Arm", "x", -Math.PI * 0.75 + _0x398ecf, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Right_Arm", "x", -Math.PI * 0.75 - _0x398ecf, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Left_Arm", "z", 0.35, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Right_Arm", "z", -0.35, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Left_Leg", "x", 0.3 + _0x3a9bcd, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Right_Leg", "x", 0.3 - _0x3a9bcd, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Torso", "x", -0.15, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Torso", "z", 0, _0x11fba5, _0x28ab3d);
      _0x1d73ae(_0x1988f7, _0x197e0b, "Left_Arm", 0.5, _0x11fba5, _0x28ab3d);
      _0x1d73ae(_0x1988f7, _0x197e0b, "Right_Arm", 0.5, _0x11fba5, _0x28ab3d);
    } else if (_0x672114.anim === "jump") {
      _0x265178(_0x1988f7, _0x197e0b, "Left_Leg", "x", 0, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Right_Leg", "x", 0, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Left_Arm", "x", -Math.PI, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Right_Arm", "x", -Math.PI, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Left_Arm", "z", 0, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Right_Arm", "z", 0, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Torso", "x", 0, _0x11fba5, _0x28ab3d);
      _0x1d73ae(_0x1988f7, _0x197e0b, "Left_Arm", -0.75, _0x11fba5, _0x28ab3d);
      _0x1d73ae(_0x1988f7, _0x197e0b, "Right_Arm", -0.75, _0x11fba5, _0x28ab3d);
    } else if (_0x672114.anim === "walk") {
      const _0x1eed23 = Math.sin(_0x5161de * 2.8 * Math.PI);
      _0x265178(_0x1988f7, _0x197e0b, "Left_Leg", "x", _0x1eed23 * 1, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Right_Leg", "x", -_0x1eed23 * 1, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Left_Arm", "x", -_0x1eed23 * 0.8, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Right_Arm", "x", _0x1eed23 * 0.8, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Left_Arm", "z", 0.05, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Right_Arm", "z", -0.05, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Torso", "x", 0.03, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Torso", "z", 0, _0x11fba5, _0x28ab3d);
      _0x1d73ae(_0x1988f7, _0x197e0b, "Left_Arm", 0, _0x11fba5, _0x28ab3d);
      _0x1d73ae(_0x1988f7, _0x197e0b, "Right_Arm", 0, _0x11fba5, _0x28ab3d);
    } else {
      const _0x2066c1 = Math.sin(_0x5161de * 1.2) * 0.015;
      _0x265178(_0x1988f7, _0x197e0b, "Left_Leg", "x", 0, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Right_Leg", "x", 0, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Left_Arm", "x", 0, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Right_Arm", "x", 0, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Left_Arm", "z", 0.1 + _0x2066c1, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Right_Arm", "z", -0.1 - _0x2066c1, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Torso", "x", _0x2066c1, _0x11fba5, _0x28ab3d);
      _0x265178(_0x1988f7, _0x197e0b, "Torso", "z", 0, _0x11fba5, _0x28ab3d);
      _0x1d73ae(_0x1988f7, _0x197e0b, "Left_Arm", 0, _0x11fba5, _0x28ab3d);
      _0x1d73ae(_0x1988f7, _0x197e0b, "Right_Arm", 0, _0x11fba5, _0x28ab3d);
    }
  }
  const _0x38428 = 3.2;
  const _0x37d485 = 400;
  const _0x3fe4f3 = _0x38428 / _0x37d485;
  const _0x364a52 = 15000;
  const _0x23ffd6 = 3;
  const _0x38222d = new Map();
  const _0x103015 = 18;
  const _0x63fdd7 = 12;
  const _0x1a8b4e = "30px system-ui,sans-serif";
  const _0x21f0f0 = 38;
  const _0x8391d3 = 12;
  const _0x1dab35 = 6;
  const _0x731fb7 = document.createElement("canvas").getContext("2d");
  _0x731fb7.font = _0x1a8b4e;
  function _0x8df3b2(_0x19684c, _0x59c067, _0x303d07) {
    const _0x4849e2 = _0x59c067.split(" ");
    const _0x269220 = [];
    let _0x52a0ec = "";
    for (const _0x4e22d2 of _0x4849e2) {
      const _0x30ab00 = _0x52a0ec ? _0x52a0ec + " " + _0x4e22d2 : _0x4e22d2;
      if (_0x19684c.measureText(_0x30ab00).width > _0x303d07 && _0x52a0ec) {
        _0x269220.push(_0x52a0ec);
        _0x52a0ec = _0x4e22d2;
      } else {
        _0x52a0ec = _0x30ab00;
      }
    }
    if (_0x52a0ec) {
      _0x269220.push(_0x52a0ec);
    }
    return _0x269220;
  }
  function _0x4958d9(_0x72002b) {
    const _0x2eeb15 = _0x38222d.get(_0x72002b);
    if (!_0x2eeb15) {
      return;
    }
    if (!_0x2eeb15.msgs.length) {
      if (_0x2eeb15.sprite) {
        _0x2eeb15.sprite.visible = false;
      }
      return;
    }
    const _0x4d1d5b = _0x37d485 - _0x103015 * 2;
    const _0x21da23 = _0x2eeb15.msgs.map(_0x4c5f8d => _0x8df3b2(_0x731fb7, _0x4c5f8d.text, _0x4d1d5b));
    const _0x302fe3 = _0x21da23.map(_0x9c3ab0 => Math.ceil(Math.min(Math.max(..._0x9c3ab0.map(_0x3ff04e => _0x731fb7.measureText(_0x3ff04e).width)) + _0x103015 * 2, _0x37d485)));
    const _0x49bbe5 = Math.max(..._0x302fe3);
    const _0x5d0704 = _0x21da23.map(_0x2f7916 => _0x2f7916.length * _0x21f0f0 + _0x103015 * 2);
    const _0x325eed = _0x5d0704.reduce((_0x53c081, _0x551f3c) => _0x53c081 + _0x551f3c, 0) + _0x1dab35 * (_0x2eeb15.msgs.length - 1) + _0x8391d3;
    const _0x3736b2 = document.createElement("canvas");
    _0x3736b2.width = _0x49bbe5;
    _0x3736b2.height = _0x325eed;
    const _0x36e23b = _0x3736b2.getContext("2d");
    _0x36e23b.font = _0x1a8b4e;
    let _0x169694 = 0;
    for (let _0x3d463f = 0; _0x3d463f < _0x2eeb15.msgs.length; _0x3d463f++) {
      const _0x586983 = _0x3d463f === _0x2eeb15.msgs.length - 1;
      const _0x37dea8 = _0x5d0704[_0x3d463f];
      const _0x132122 = _0x21da23[_0x3d463f];
      const _0x4b8edb = _0x302fe3[_0x3d463f];
      const _0x517e86 = (_0x49bbe5 - _0x4b8edb) / 2;
      _0x36e23b.fillStyle = "rgba(255,255,255,0.95)";
      _0x36e23b.beginPath();
      _0x36e23b.moveTo(_0x517e86 + _0x63fdd7, _0x169694);
      _0x36e23b.lineTo(_0x517e86 + _0x4b8edb - _0x63fdd7, _0x169694);
      _0x36e23b.arcTo(_0x517e86 + _0x4b8edb, _0x169694, _0x517e86 + _0x4b8edb, _0x169694 + _0x63fdd7, _0x63fdd7);
      _0x36e23b.lineTo(_0x517e86 + _0x4b8edb, _0x169694 + _0x37dea8 - _0x63fdd7);
      _0x36e23b.arcTo(_0x517e86 + _0x4b8edb, _0x169694 + _0x37dea8, _0x517e86 + _0x4b8edb - _0x63fdd7, _0x169694 + _0x37dea8, _0x63fdd7);
      if (_0x586983) {
        _0x36e23b.lineTo(_0x49bbe5 / 2 + _0x8391d3, _0x169694 + _0x37dea8);
        _0x36e23b.lineTo(_0x49bbe5 / 2, _0x169694 + _0x37dea8 + _0x8391d3);
        _0x36e23b.lineTo(_0x49bbe5 / 2 - _0x8391d3, _0x169694 + _0x37dea8);
      }
      _0x36e23b.lineTo(_0x517e86 + _0x63fdd7, _0x169694 + _0x37dea8);
      _0x36e23b.arcTo(_0x517e86, _0x169694 + _0x37dea8, _0x517e86, _0x169694 + _0x37dea8 - _0x63fdd7, _0x63fdd7);
      _0x36e23b.lineTo(_0x517e86, _0x169694 + _0x63fdd7);
      _0x36e23b.arcTo(_0x517e86, _0x169694, _0x517e86 + _0x63fdd7, _0x169694, _0x63fdd7);
      _0x36e23b.closePath();
      _0x36e23b.fill();
      _0x36e23b.fillStyle = "#111";
      _0x36e23b.textAlign = "center";
      _0x36e23b.textBaseline = "top";
      for (let _0x3d19c1 = 0; _0x3d19c1 < _0x132122.length; _0x3d19c1++) {
        _0x36e23b.fillText(_0x132122[_0x3d19c1], _0x49bbe5 / 2, _0x169694 + _0x103015 + _0x3d19c1 * _0x21f0f0);
      }
      _0x169694 += _0x37dea8 + (_0x586983 ? _0x8391d3 : _0x1dab35);
    }
    if (!_0x2eeb15.sprite) {
      _0x2eeb15.sprite = new THREE.Sprite(new THREE.SpriteMaterial({
        depthTest: false,
        transparent: true
      }));
      _vortex.scene.add(_0x2eeb15.sprite);
    }
    _0x2eeb15.sprite.material.map?.dispose();
    _0x2eeb15.sprite.material.map = new THREE.CanvasTexture(_0x3736b2);
    _0x2eeb15.sprite.material.needsUpdate = true;
    _0x2eeb15.sprite.scale.set(_0x49bbe5 * _0x3fe4f3, _0x325eed * _0x3fe4f3, 1);
    _0x2eeb15.sprite.visible = true;
  }
  function _0x200010(_0x3196b1, _0x24c591) {
    let _0xa00be7 = _0x38222d.get(_0x3196b1);
    if (!_0xa00be7) {
      _0xa00be7 = {
        msgs: [],
        sprite: null
      };
      _0x38222d.set(_0x3196b1, _0xa00be7);
    }
    if (_0xa00be7.msgs.length >= _0x23ffd6) {
      clearTimeout(_0xa00be7.msgs.shift().timer);
    }
    const _0x66ee3e = {
      text: _0x24c591,
      timer: null
    };
    _0xa00be7.msgs.push(_0x66ee3e);
    _0x4958d9(_0x3196b1);
    _0x66ee3e.timer = setTimeout(() => {
      const _0x38baac = _0xa00be7.msgs.indexOf(_0x66ee3e);
      if (_0x38baac !== -1) {
        _0xa00be7.msgs.splice(_0x38baac, 1);
      }
      if (!_0xa00be7.msgs.length) {
        if (_0xa00be7.sprite) {
          _0xa00be7.sprite.visible = false;
        }
        _0x38222d.delete(_0x3196b1);
      } else {
        _0x4958d9(_0x3196b1);
      }
    }, _0x364a52);
  }
  function _0x16c9a8() {
    const _0x544933 = _vortex.getCharHeight() - _vortex.getCharFootOffset() + 0.4;
    for (const [_0x487393, _0x1a27e6] of _0x38222d) {
      if (!_0x1a27e6.sprite || !_0x1a27e6.msgs.length) {
        if (_0x1a27e6.sprite) {
          _0x1a27e6.sprite.visible = false;
        }
        continue;
      }
      let _0xde9bf9;
      let _0x1335e7;
      let _0x18a48b;
      if (_0x487393 === _0x177bdf) {
        const _0x5ed9a8 = _vortex.getCharacter();
        if (!_0x5ed9a8) {
          _0x1a27e6.sprite.visible = false;
          continue;
        }
        _0xde9bf9 = _0x5ed9a8.position.x;
        _0x1335e7 = _vortex.getCharBubbleBase();
        _0x18a48b = _0x5ed9a8.position.z;
      } else {
        const _0x57da54 = _0x1e4b5c.get(_0x487393);
        if (!_0x57da54 || !_0x57da54.meshes || !_0x57da54.meshes.grp.visible) {
          _0x1a27e6.sprite.visible = false;
          continue;
        }
        const _0xf0299e = _0x57da54.meshes.grp;
        _0xde9bf9 = _0xf0299e.position.x;
        _0x1335e7 = _0xf0299e.position.y + _0x544933;
        _0x18a48b = _0xf0299e.position.z;
      }
      _0x1a27e6.sprite.position.set(_0xde9bf9, _0x1335e7 + _0x1a27e6.sprite.scale.y / 2, _0x18a48b);
    }
  }
  const _0x1e4b5c = new Map();
  let _0x177bdf = null;
  let _0x136b29 = null;
  let _0x13ed29 = null;
  const _0x301b94 = new Map();
  let _0x558ded = new Set();
  let _0xe67b53 = new Set();
  let _0x5e0e16 = new Set();
  function _0x3d2468(_0x4fb757) {
    if (_0x558ded.has(_0x4fb757)) {
      return "friends";
    }
    if (_0xe67b53.has(_0x4fb757)) {
      return "request_received";
    }
    if (_0x5e0e16.has(_0x4fb757)) {
      return "request_sent";
    }
    return "none";
  }
  async function _0x148337() {
    const [_0x53b915, _0xc6b95, _0x43fe8e] = await Promise.all([fetch("/api/friends").then(_0x3c7478 => _0x3c7478.ok ? _0x3c7478.json() : []), fetch("/api/friends/requests/incoming").then(_0x1cde85 => _0x1cde85.ok ? _0x1cde85.json() : []), fetch("/api/friends/requests/outgoing").then(_0x396bb4 => _0x396bb4.ok ? _0x396bb4.json() : [])]);
    _0x558ded = new Set(_0x53b915.map(_0x5de286 => _0x5de286.id));
    _0xe67b53 = new Set(_0xc6b95.map(_0x4bd19b => _0x4bd19b.from_user_id));
    _0x5e0e16 = new Set(_0x43fe8e.map(_0x447dd0 => _0x447dd0.to_user_id));
    const _0x518024 = {};
    for (const [_0x265927] of _0x1e4b5c) {
      _0x518024[_0x265927] = _0x3d2468(_0x265927);
    }
    Leaderboard.setFriendStatuses(_0x518024);
  }
  let _0x5b0671 = 0;
  const _0x5dadfd = 3;
  async function _0x26a6e4() {
    await window._fpReady;
    const _0x43e78 = await fetch("/api/ws-ticket?game_id=" + (window.GAME_ID || 0) + "&fingerprint=" + encodeURIComponent(window._fingerprint || "") + "&fp_token=" + encodeURIComponent(window._fpToken || "")).then(_0x37d1c8 => _0x37d1c8.ok ? _0x37d1c8.json() : null);
    if (!_0x43e78) {
      setTimeout(_0x26a6e4, 4000);
      return;
    }
    const _0x4c9ca3 = location.protocol === "https:" ? "wss" : "ws";
    _0x136b29 = new WebSocket(_0x4c9ca3 + "://" + location.host + "/ws/play?t=" + _0x43e78.ticket);
    _0x136b29.onopen = () => {
      clearTimeout(_0x136b29._retry);
      _0x5b0671 = 0;
      _0x219995();
    };
    _0x136b29.onmessage = _0x594cc4 => _0xe7535f(JSON.parse(_0x594cc4.data));
    _0x136b29.onclose = () => {
      _0x439fc4();
      if (!_0x136b29._kicked) {
        if (_0x5b0671 >= _0x5dadfd) {
          return;
        }
        _0x5b0671++;
        _0x136b29._retry = setTimeout(_0x26a6e4, 3000);
      }
    };
    _0x136b29.onerror = () => _0x136b29.close();
  }
  function _0xe7535f(_0x228b2f) {
    switch (_0x228b2f.type) {
      case "kicked":
        {
          _0x136b29._kicked = true;
          _0x136b29.close();
          window.location.href = "/";
          break;
        }
      case "kick":
        {
          _0x136b29._kicked = true;
          _0x136b29.close();
          if (window.Notifications && _0x228b2f.reason) {
            window.Notifications.error(_0x228b2f.reason);
          }
          setTimeout(() => {
            window.location.href = "/";
          }, 3000);
          break;
        }
      case "init":
        {
          _0x177bdf = _0x228b2f.id;
          Leaderboard.setMyId(_0x177bdf);
          Leaderboard.addPlayer({
            id: _0x177bdf,
            username: _0x228b2f.username,
            is_staff: _0x228b2f.is_staff,
            is_booster: _0x228b2f.is_booster
          });
          for (const _0x222c63 of _0x228b2f.players) {
            _0x4e5baa(_0x222c63.id, _0x222c63.username, _0x222c63.is_staff, _0x222c63.is_booster, _0x222c63.shirt_id);
          }
          if (_0x228b2f.shirt_id) {
            _vortex.applyShirt(_0x3d3f7b(_0x228b2f.shirt_id));
          }
          _0x148337();
          break;
        }
      case "join":
        {
          if (_0x228b2f.id === _0x177bdf) {
            break;
          }
          _0x4e5baa(_0x228b2f.id, _0x228b2f.username, _0x228b2f.is_staff, _0x228b2f.is_booster, _0x228b2f.shirt_id);
          Chat.systemPlayer(_0x228b2f.username, _0x228b2f.username + " joined.", false);
          break;
        }
      case "leave":
        {
          Chat.systemPlayer(_0x228b2f.username, _0x228b2f.username + " left.", false);
          _0x36045e(_0x228b2f.id);
          break;
        }
      case "kick_log":
        {
          Chat.clearPlayerMsg(_0x228b2f.username);
          Chat.systemRed(_0x228b2f.username + " was kicked by " + _0x228b2f.by + ".");
          _0x36045e(_0x228b2f.id);
          break;
        }
      case "states":
        {
          for (const _0xb00899 of _0x228b2f.players) {
            const _0x36eddb = _0x1e4b5c.get(_0xb00899.id);
            if (!_0x36eddb) {
              continue;
            }
            _0x36eddb.tPos.set(_0xb00899.x, _0xb00899.y, _0xb00899.z);
            _0x36eddb.tRy = _0xb00899.ry;
            _0x36eddb.anim = _0xb00899.anim;
            _0x36eddb.seen = performance.now();
            if (_0x36eddb.meshes && !_0x36eddb.meshes.grp.visible) {
              _0x36eddb.meshes.grp.position.copy(_0x36eddb.tPos);
              _0x36eddb.meshes.grp.rotation.y = _0xb00899.ry;
              _0x36eddb.meshes.grp.visible = true;
            }
          }
          break;
        }
      case "chat":
        {
          Chat.message(_0x228b2f.username, _0x228b2f.msg, _0x228b2f.id === _0x177bdf, _0x228b2f.is_staff, _0x228b2f.is_owner, _0x228b2f.is_booster);
          _0x200010(_0x228b2f.id, _0x228b2f.msg);
          break;
        }
      case "chat_throttled":
        {
          Chat.warn("Please wait " + _0x228b2f.wait + "s before sending another message.");
          break;
        }
      case "chat_blocked":
        {
          Chat.warn(_0x228b2f.msg);
          break;
        }
      case "friend_request":
        {
          window.Notifications?.friendRequest(_0x228b2f.from_id, _0x228b2f.from_username);
          _0xe67b53.add(_0x228b2f.from_id);
          Leaderboard.setFriendStatus(_0x228b2f.from_id, "request_received");
          break;
        }
      case "friend_request_cancelled":
        {
          window.Notifications?.friendRequestCancelled?.(_0x228b2f.from_id);
          _0xe67b53.delete(_0x228b2f.from_id);
          Leaderboard.setFriendStatus(_0x228b2f.from_id, "none");
          break;
        }
      case "friend_accepted":
        {
          window.Notifications?.friendAccepted(_0x228b2f.by_username);
          _0x558ded.add(_0x228b2f.by_id);
          _0x5e0e16.delete(_0x228b2f.by_id);
          Leaderboard.setFriendStatus(_0x228b2f.by_id, "friends");
          break;
        }
      case "followed":
        {
          window.Notifications?.followed?.(_0x228b2f.by_username);
          break;
        }
      case "unfollowed":
        {
          window.Notifications?.unfollowed?.(_0x228b2f.by_username);
          break;
        }
      case "shirt_update":
        {
          const _0x3a3465 = _0x1e4b5c.get(_0x228b2f.id);
          if (_0x3a3465?.meshes) {
            _vortex.applyShirtToMesh(_0x3a3465.meshes.shirtMesh, _0x3d3f7b(_0x228b2f.shirt_id));
          } else {
            const _0x546e7e = _0x301b94.get(_0x228b2f.id);
            if (_0x546e7e) {
              _0x546e7e.shirt_id = _0x228b2f.shirt_id;
            }
          }
          break;
        }
      case "purchase_token":
        {
          window._onPurchaseToken?.(_0x228b2f.item_id, _0x228b2f.token);
          break;
        }
    }
  }
  window._mpSetFriendStatus = function (_0x4e8c20, _0x2a26a7) {
    if (_0x2a26a7 === "friends") {
      _0x558ded.add(_0x4e8c20);
      _0xe67b53.delete(_0x4e8c20);
      _0x5e0e16.delete(_0x4e8c20);
    } else if (_0x2a26a7 === "request_sent") {
      _0x5e0e16.add(_0x4e8c20);
    } else if (_0x2a26a7 === "none") {
      _0x558ded.delete(_0x4e8c20);
      _0xe67b53.delete(_0x4e8c20);
      _0x5e0e16.delete(_0x4e8c20);
    }
    Leaderboard.setFriendStatus(_0x4e8c20, _0x2a26a7);
  };
  function _0x3d3f7b(_0x3c4d60) {
    if (_0x3c4d60) {
      return "assets/clothing/" + _0x3c4d60 + ".png";
    } else {
      return null;
    }
  }
  function _0x4e5baa(_0x3bcdec, _0x479e4b, _0x45f19b, _0x5952fa, _0x534900) {
    if (_0x1e4b5c.has(_0x3bcdec)) {
      return;
    }
    const _0x342a07 = _0x3d3f7b(_0x534900);
    let _0x42b397 = null;
    if (_vortex.getCharacter()) {
      try {
        _0x42b397 = _0x5b1a66(_0x479e4b, _0x342a07);
      } catch (_0x3bc3b4) {
        console.error("[mp] makeRemote failed:", _0x3bc3b4);
      }
    }
    if (!_0x42b397) {
      _0x301b94.set(_0x3bcdec, {
        username: _0x479e4b,
        is_staff: _0x45f19b,
        is_booster: _0x5952fa,
        shirt_id: _0x534900
      });
    }
    _0x1e4b5c.set(_0x3bcdec, {
	  username: _0x479e4b;
      meshes: _0x42b397,
      tPos: new THREE.Vector3(0, -999, 0),
      tRy: 0,
      anim: "idle",
      animTime: 0,
      seen: performance.now()
    });
    Leaderboard.addPlayer({
      id: _0x3bcdec,
      username: _0x479e4b,
      is_staff: _0x45f19b,
      is_booster: _0x5952fa
    });
    Leaderboard.setFriendStatus(_0x3bcdec, _0x3d2468(_0x3bcdec));
	window._remotes = _0x1e4b5c;
  }
  function _0x36045e(_0x7f3efd) {
    const _0x22f2e7 = _0x1e4b5c.get(_0x7f3efd);
    if (!_0x22f2e7) {
      return;
    }
    const _0x1da603 = _0x38222d.get(_0x7f3efd);
    if (_0x1da603) {
      for (const _0x37d6b5 of _0x1da603.msgs) {
        clearTimeout(_0x37d6b5.timer);
      }
      if (_0x1da603.sprite) {
        _vortex.scene.remove(_0x1da603.sprite);
        _0x1da603.sprite.material.map?.dispose();
        _0x1da603.sprite.material.dispose();
      }
      _0x38222d.delete(_0x7f3efd);
    }
    _0x36ece4(_0x22f2e7.meshes);
    _0x301b94.delete(_0x7f3efd);
    _0x1e4b5c.delete(_0x7f3efd);
    Leaderboard.removePlayer(_0x7f3efd);
	window._remotes = _0x1e4b5c;
  }
  function _0x219995() {
    if (_0x13ed29) {
      return;
    }
    _0x13ed29 = setInterval(() => {
      if (!_0x136b29 || _0x136b29.readyState !== WebSocket.OPEN) {
        return;
      }
      const _0x3c211b = _vortex.getCharacter();
      if (!_0x3c211b) {
        return;
      }
      const _0x5056ac = _vortex.keys;
      const _0x16bf52 = _0x5056ac.KeyW || _0x5056ac.KeyS || _0x5056ac.KeyA || _0x5056ac.KeyD || _0x5056ac.ArrowUp || _0x5056ac.ArrowDown || _0x5056ac.ArrowLeft || _0x5056ac.ArrowRight;
      const _0x2111fd = _vortex.getClimbState();
      const _0x2ab7af = _vortex.getGrounded();
      const _0x20fad5 = _0x2111fd !== "none" ? "climb" : !_0x2ab7af ? "jump" : _0x16bf52 ? "walk" : "idle";
      let _0x46d56d = _0x3c211b.rotation.y % (Math.PI * 2);
      if (_0x46d56d > Math.PI) {
        _0x46d56d -= Math.PI * 2;
      } else if (_0x46d56d < -Math.PI) {
        _0x46d56d += Math.PI * 2;
      }
      _0x136b29.send(JSON.stringify({
        type: "state",
        x: _0x3c211b.position.x,
        y: _0x3c211b.position.y,
        z: _0x3c211b.position.z,
        ry: _0x46d56d,
        anim: _0x20fad5
      }));
    }, 50);
  }
  function _0x439fc4() {
    clearInterval(_0x13ed29);
    _0x13ed29 = null;
  }
  const _0x570ee5 = 12;
  const _0x403036 = 6400;
  window._mpUpdate = function (_0xf5d0cb) {
    if (_0x301b94.size > 0 && _vortex.getCharacter()) {
      for (const [_0x561a43, _0xed4128] of _0x301b94) {
        const _0x59218c = _0x1e4b5c.get(_0x561a43);
        if (_0x59218c && !_0x59218c.meshes) {
          try {
            _0x59218c.meshes = _0x5b1a66(_0xed4128.username, _0x3d3f7b(_0xed4128.shirt_id));
          } catch (_0x5038c3) {
            console.error("[mp] makeRemote failed:", _0x5038c3);
          }
          if (_0x59218c.meshes) {
            _0x59218c.meshes.grp.visible = false;
          }
        }
      }
      _0x301b94.clear();
    }
    const _0x32865f = performance.now();
    const _0x46acf1 = _vortex.getCamera?.();
    const _0x2ffccf = _0x46acf1 ? _0x46acf1.position : null;
    for (const [, _0x574193] of _0x1e4b5c) {
      if (!_0x574193.meshes) {
        continue;
      }
      const _0x52576f = _0x574193.meshes.grp;
      if (_0x32865f - _0x574193.seen > 5000) {
        _0x52576f.visible = false;
        continue;
      }
      _0x52576f.position.lerp(_0x574193.tPos, Math.min(1, _0x570ee5 * _0xf5d0cb));
      let _0x20fb8d = _0x574193.tRy - _0x52576f.rotation.y;
      _0x20fb8d = (_0x20fb8d % (Math.PI * 2) + Math.PI * 3) % (Math.PI * 2) - Math.PI;
      _0x52576f.rotation.y += _0x20fb8d * Math.min(1, _0x570ee5 * _0xf5d0cb);
      if (_0x52576f.rotation.y > Math.PI) {
        _0x52576f.rotation.y -= Math.PI * 2;
      } else if (_0x52576f.rotation.y < -Math.PI) {
        _0x52576f.rotation.y += Math.PI * 2;
      }
      if (!_0x2ffccf || _0x52576f.position.distanceToSquared(_0x2ffccf) < _0x403036) {
        _0x177f99(_0x574193, _0xf5d0cb);
      }
    }
    _0x16c9a8();
  };
  window._mpSendChat = function (_0x45661d) {
    if (!_0x136b29 || _0x136b29.readyState !== WebSocket.OPEN) {
      return;
    }
    _0x136b29.send(JSON.stringify({
      type: "chat",
      msg: _0x45661d
    }));
  };
  window._mpSendWs = function (_0x57a8cf) {
    if (!_0x136b29 || _0x136b29.readyState !== WebSocket.OPEN) {
      return;
    }
    _0x136b29.send(JSON.stringify(_0x57a8cf));
  };
  window._mpCreateDummy = function (_0x4c2c3b, _0x4ea405, _0x581bd0, _0x154686, _0x1f4161 = 0) {
    const _0x4c34ac = _0x48aa48();
    if (!_0x4c34ac) {
      return null;
    }
    _0x4c34ac.position.set(_0x4c2c3b, _0x4ea405, _0x581bd0);
    _0x4c34ac.rotation.y = _0x1f4161;
    _0x4c34ac.visible = true;
    const _0x3964a9 = _vortex.buildShirtOverlay(_0x4c34ac);
    if (_0x3964a9 && _0x154686) {
      _vortex.applyShirtToMesh(_0x3964a9, _0x154686);
    }
    return _0x4c34ac;
  };
  _0x26a6e4();
})();