(function () {
  const _0x3585f8 = document.getElementById("chat-window");
  const _0x20667a = document.getElementById("chat-messages");
  const _0x1b0da0 = document.getElementById("chat-input");
  const _0x17dd19 = document.getElementById("chat-send");
  const _0x283153 = document.getElementById("chat-toggle-btn");
  const _0x4823c9 = document.getElementById("unread-badge");
  let _0x337191 = true;
  let _0x4bb313 = 0;
  let _0x30d6e5 = "";
  let _0x3acea0 = 0;
  let _0x2f17aa = 0;
  let _0x940273 = false;
  function _0x29ccee() {
    return Math.min(_0x3acea0, _0x2f17aa);
  }
  function _0x33c99e() {
    return Math.max(_0x3acea0, _0x2f17aa);
  }
  function _0x20f925() {
    return _0x3acea0 !== _0x2f17aa;
  }
  function _0x3a334b(_0x3b6b86) {
    return Math.max(0, Math.min(_0x30d6e5.length, _0x3b6b86));
  }
  function _0x318496() {
    const _0x30b005 = _0x29ccee();
    const _0x58127e = _0x33c99e();
    const _0x50d56e = _0x30d6e5.length === 0 && !_0x940273;
    if (_0x50d56e) {
      _0x1b0da0.innerHTML = "<span class=\"chat-placeholder\">Click or press / to chat</span>";
      return;
    }
    let _0xe420e0 = "";
    if (_0x20f925()) {
      _0xe420e0 += _0x25e6a1(_0x30d6e5.slice(0, _0x30b005));
      _0xe420e0 += "<span class=\"chat-sel\">" + _0x25e6a1(_0x30d6e5.slice(_0x30b005, _0x58127e)) + "</span>";
      _0xe420e0 += _0x25e6a1(_0x30d6e5.slice(_0x58127e));
    } else {
      const _0xf22e3f = _0x2f17aa;
      _0xe420e0 += _0x25e6a1(_0x30d6e5.slice(0, _0xf22e3f));
      if (_0x940273) {
        _0xe420e0 += "<span class=\"chat-caret\"></span>";
      }
      _0xe420e0 += _0x25e6a1(_0x30d6e5.slice(_0xf22e3f));
    }
    _0x1b0da0.innerHTML = _0xe420e0;
  }
  function _0x23d616(_0x844bc5) {
    const _0x400d8a = _0x29ccee();
    const _0x5bc1a6 = _0x33c99e();
    _0x30d6e5 = _0x30d6e5.slice(0, _0x400d8a) + _0x844bc5 + _0x30d6e5.slice(_0x5bc1a6);
    const _0x14574d = _0x3a334b(_0x400d8a + _0x844bc5.length);
    _0x3acea0 = _0x2f17aa = _0x14574d;
    _0x318496();
  }
  function _0x339629(_0x569ed3, _0x11336b) {
    _0x30d6e5 = _0x30d6e5.slice(0, _0x569ed3) + _0x30d6e5.slice(_0x11336b);
    _0x3acea0 = _0x2f17aa = _0x3a334b(_0x569ed3);
    _0x318496();
  }
  const _0x271365 = ["#60a5fa", "#34d399", "#f87171", "#fbbf24", "#a78bfa", "#fb923c", "#f472b6"];
  function _0x13b928(_0x37775f) {
    let _0x5c5752 = 0;
    for (const _0x405a9f of _0x37775f) {
      _0x5c5752 = _0x5c5752 * 31 + _0x405a9f.charCodeAt(0) & 65535;
    }
    return _0x271365[_0x5c5752 % _0x271365.length];
  }
  function _0x25e6a1(_0x572cbb) {
    return _0x572cbb.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function _0x1eb1ee() {
    _0x20667a.scrollTop = _0x20667a.scrollHeight;
  }
  function _0x390ae4(_0x12cabf) {
    const _0x505812 = _0x20667a.scrollHeight - _0x20667a.scrollTop - _0x20667a.clientHeight < 60;
    const _0x284a06 = document.createElement("div");
    _0x284a06.innerHTML = _0x12cabf;
    _0x20667a.appendChild(_0x284a06.firstChild);
    if (_0x505812) {
      _0x1eb1ee();
    }
    if (!_0x337191) {
      _0x4bb313 = Math.min(_0x4bb313 + 1, 99);
      _0x4823c9.textContent = _0x4bb313 >= 99 ? "99+" : String(_0x4bb313);
      _0x4823c9.classList.remove("hidden");
    }
  }
  function _0xe92746(_0x38209a, _0x43677a, _0x2c0117, _0x2d29d6, _0x7cc8eb, _0x546cd3) {
    let _0x1b19f0;
    if (_0x7cc8eb) {
      _0x1b19f0 = "<span class=\"msg-name msg-gradient-owner\">" + _0x25e6a1(_0x38209a) + "</span>";
    } else if (_0x2d29d6) {
      _0x1b19f0 = "<span class=\"msg-name msg-gradient-staff\">" + _0x25e6a1(_0x38209a) + "</span>";
    } else if (_0x546cd3) {
      _0x1b19f0 = "<span class=\"msg-name msg-gradient-booster\">" + _0x25e6a1(_0x38209a) + "</span>";
    } else {
      const _0x58a3b3 = _0x2c0117 ? "#fff" : _0x13b928(_0x38209a);
      _0x1b19f0 = "<span class=\"msg-name\" style=\"color:" + _0x58a3b3 + "\">" + _0x25e6a1(_0x38209a) + "</span>";
    }
    _0x390ae4("<div class=\"msg" + (_0x2c0117 ? " msg-self" : "") + "\">" + _0x1b19f0 + ": <span class=\"msg-text\">" + _0x25e6a1(_0x43677a) + "</span></div>");
  }
  function _0x35981d(_0x36bf05) {
    _0x390ae4("<div class=\"msg-system\">" + _0x25e6a1(_0x36bf05) + "</div>");
  }
  function _0x4e69cb(_0xc24809) {
    _0x390ae4("<div class=\"msg-system msg-system-red\">" + _0x25e6a1(_0xc24809) + "</div>");
  }
  const _0x2da8f6 = {};
  const _0x1ad3a9 = {};
  function _0x18a508(_0x50f96b, _0x62974e, _0x307a1f) {
    const _0x31a5ed = _0x20667a.scrollHeight - _0x20667a.scrollTop - _0x20667a.clientHeight < 60;
    const _0xffc95b = _0x2da8f6[_0x50f96b];
    const _0x4be8d3 = _0x20667a.children;
    const _0x436337 = _0x4be8d3.length;
    const _0x77231b = _0xffc95b && _0xffc95b.isConnected && (_0x4be8d3[_0x436337 - 1] === _0xffc95b || _0x4be8d3[_0x436337 - 2] === _0xffc95b || _0x4be8d3[_0x436337 - 3] === _0xffc95b || _0x4be8d3[_0x436337 - 4] === _0xffc95b || _0x4be8d3[_0x436337 - 5] === _0xffc95b);
    if (_0x77231b) {
      _0x1ad3a9[_0x50f96b] = (_0x1ad3a9[_0x50f96b] || 1) + 1;
      const _0x3ee5c2 = _0x307a1f ? "msg-system msg-system-red" : "msg-system";
      _0xffc95b.className = _0x3ee5c2;
      _0xffc95b.textContent = _0x62974e + " (" + _0x1ad3a9[_0x50f96b] + ")";
      if (_0x31a5ed) {
        _0x1eb1ee();
      }
    } else {
      _0x1ad3a9[_0x50f96b] = 1;
      const _0x20de8d = document.createElement("div");
      _0x20de8d.className = _0x307a1f ? "msg-system msg-system-red" : "msg-system";
      _0x20de8d.textContent = _0x62974e;
      _0x2da8f6[_0x50f96b] = _0x20de8d;
      _0x20667a.appendChild(_0x20de8d);
      if (_0x31a5ed) {
        _0x1eb1ee();
      }
      if (!_0x337191) {
        _0x4bb313 = Math.min(_0x4bb313 + 1, 99);
        _0x4823c9.textContent = _0x4bb313 >= 99 ? "99+" : String(_0x4bb313);
        _0x4823c9.classList.remove("hidden");
      }
    }
  }
  let _0x5d4b2c = null;
  const _0x40e1d9 = document.createElement("div");
  _0x40e1d9.className = "chat-warn hidden";
  _0x3585f8.appendChild(_0x40e1d9);
  function _0x4224b7(_0x5a0c57) {
    _0x40e1d9.textContent = _0x5a0c57;
    _0x40e1d9.classList.remove("hidden");
    clearTimeout(_0x5d4b2c);
    _0x5d4b2c = setTimeout(() => _0x40e1d9.classList.add("hidden"), 3000);
  }
  function _0xa3b451() {
    _0x337191 = true;
    _0x3585f8.classList.remove("hidden");
    _0x4bb313 = 0;
    _0x4823c9.classList.add("hidden");
    _0x1eb1ee();
  }
  function _0x16d3db() {
    _0x337191 = false;
    _0x3585f8.classList.add("hidden");
    _0x38874b();
  }
  _0x283153.addEventListener("click", () => _0x337191 ? _0x16d3db() : _0xa3b451());
  function _0x3b1383() {
    const _0x9deb73 = _0x30d6e5.trim();
    if (!_0x9deb73) {
      _0x38874b();
      return;
    }
    window._mpSendChat?.(_0x9deb73);
    _0x30d6e5 = "";
    _0x3acea0 = _0x2f17aa = 0;
    _0x38874b();
  }
  _0x17dd19.addEventListener("click", _0x3b1383);
  function _0x3ef5db() {
    if (!_0x337191) {
      _0xa3b451();
    }
    _0x940273 = true;
    window._chatFocused = true;
    _0x1b0da0.classList.add("chat-active");
    _0x318496();
  }
  function _0x38874b() {
    _0x940273 = false;
    window._chatFocused = false;
    _0x1b0da0.classList.remove("chat-active");
    _0x318496();
  }
  document.addEventListener("keydown", _0x5058f1 => {
    if (document.pointerLockElement && !_0x940273 && _0x5058f1.key === "/") {
      _0x5058f1.preventDefault();
      _0x3ef5db();
      return;
    }
    if (!_0x940273) {
      return;
    }
    _0x5058f1.stopPropagation();
    const _0x127b0b = _0x5058f1.ctrlKey || _0x5058f1.metaKey;
    if (_0x5058f1.key === "Enter") {
      _0x5058f1.preventDefault();
      _0x3b1383();
      return;
    }
    if (_0x5058f1.key === "Escape") {
      _0x5058f1.preventDefault();
      _0x38874b();
      return;
    }
    if (_0x127b0b && _0x5058f1.key === "a") {
      _0x5058f1.preventDefault();
      _0x3acea0 = 0;
      _0x2f17aa = _0x30d6e5.length;
      _0x318496();
      return;
    }
    if (_0x127b0b && _0x5058f1.key === "c") {
      if (_0x20f925()) {
        navigator.clipboard?.writeText(_0x30d6e5.slice(_0x29ccee(), _0x33c99e())).catch(() => {});
      }
      return;
    }
    if (_0x127b0b && _0x5058f1.key === "x") {
      _0x5058f1.preventDefault();
      if (_0x20f925()) {
        navigator.clipboard?.writeText(_0x30d6e5.slice(_0x29ccee(), _0x33c99e())).catch(() => {});
        _0x339629(_0x29ccee(), _0x33c99e());
      }
      return;
    }
    if (_0x127b0b && _0x5058f1.key === "v") {
      _0x5058f1.preventDefault();
      navigator.clipboard?.readText().then(_0x1df5b4 => {
        const _0x56f895 = _0x1df5b4.replace(/[\n\r]/g, " ");
        const _0x29ae9d = 200 - (_0x30d6e5.length - (_0x33c99e() - _0x29ccee()));
        _0x23d616(_0x56f895.slice(0, _0x29ae9d));
      }).catch(() => {});
      return;
    }
    if (_0x5058f1.key === "ArrowLeft") {
      _0x5058f1.preventDefault();
      if (_0x5058f1.shiftKey) {
        _0x2f17aa = _0x3a334b(_0x2f17aa - 1);
      } else if (_0x20f925()) {
        _0x3acea0 = _0x2f17aa = _0x29ccee();
      } else {
        _0x3acea0 = _0x2f17aa = _0x3a334b(_0x2f17aa - 1);
      }
      _0x318496();
      return;
    }
    if (_0x5058f1.key === "ArrowRight") {
      _0x5058f1.preventDefault();
      if (_0x5058f1.shiftKey) {
        _0x2f17aa = _0x3a334b(_0x2f17aa + 1);
      } else if (_0x20f925()) {
        _0x3acea0 = _0x2f17aa = _0x33c99e();
      } else {
        _0x3acea0 = _0x2f17aa = _0x3a334b(_0x2f17aa + 1);
      }
      _0x318496();
      return;
    }
    if (_0x5058f1.key === "Home") {
      _0x5058f1.preventDefault();
      if (_0x5058f1.shiftKey) {
        _0x2f17aa = 0;
      } else {
        _0x3acea0 = _0x2f17aa = 0;
      }
      _0x318496();
      return;
    }
    if (_0x5058f1.key === "End") {
      _0x5058f1.preventDefault();
      if (_0x5058f1.shiftKey) {
        _0x2f17aa = _0x30d6e5.length;
      } else {
        _0x3acea0 = _0x2f17aa = _0x30d6e5.length;
      }
      _0x318496();
      return;
    }
    if (_0x5058f1.key === "Backspace") {
      _0x5058f1.preventDefault();
      if (_0x20f925()) {
        _0x339629(_0x29ccee(), _0x33c99e());
      } else if (_0x2f17aa > 0) {
        _0x339629(_0x2f17aa - 1, _0x2f17aa);
      }
      return;
    }
    if (_0x5058f1.key === "Delete") {
      _0x5058f1.preventDefault();
      if (_0x20f925()) {
        _0x339629(_0x29ccee(), _0x33c99e());
      } else if (_0x2f17aa < _0x30d6e5.length) {
        _0x339629(_0x2f17aa, _0x2f17aa + 1);
      }
      return;
    }
    if (!_0x127b0b && _0x5058f1.key.length === 1) {
      _0x5058f1.preventDefault();
      const _0x4ce65a = 200 - (_0x30d6e5.length - (_0x33c99e() - _0x29ccee()));
      if (_0x4ce65a > 0) {
        _0x23d616(_0x5058f1.key);
      }
      return;
    }
  });
  function _0x1ff54d(_0x5df42a) {
    delete _0x2da8f6[_0x5df42a];
    delete _0x1ad3a9[_0x5df42a];
  }
  window.Chat = {
    message: _0xe92746,
    system: _0x35981d,
    systemRed: _0x4e69cb,
    systemPlayer: _0x18a508,
    clearPlayerMsg: _0x1ff54d,
    warn: _0x4224b7,
    open: _0xa3b451,
    close: _0x16d3db,
    activate: _0x3ef5db,
    deactivate: _0x38874b,
    send: _0x3b1383
  };
})();