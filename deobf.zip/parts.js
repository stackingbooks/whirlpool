const RED = 12855324;
const BLUE = 879020;
const YELLOW = 15912247;
const ORANGE = 14841370;
const PURPLE = 5978763;
const LIME = 5093451;
const WHITE = 15922162;
const DARK = 1710638;
const PINK = 15221651;
const TEAL = 46296;
addStud(8, 3, 8, BLUE, 0, G, -20);
addStud(6, 1, 6, RED, 0, G + 3, -32);
addStud(8, 1, 8, BLUE, 17, 1.6, 0);
addStud(6, 1, 6, BLUE, 29, 1.6, 0);
addStud(4, 1, 4, TEAL, 40, 1.6, 0);
addStud(3, 1, 3, TEAL, 50, 1.6, 0);
addStud(2, 1, 2, YELLOW, 59, 1.6, 0);
addStud(2, 1, 2, YELLOW, 68, 1.6, 0);
addStud(2, 1, 2, ORANGE, 77, 1.6, 0);
addStud(2, 1, 2, RED, 86, 1.6, 0);
addStud(2, 1, 2, RED, 95, 4.6, 8);
addStud(2, 1, 2, ORANGE, 103, 7.6, 0);
addStud(2, 1, 2, YELLOW, 112, 10.6, 8);
addStud(2, 1, 2, TEAL, 120, 13.6, 0);
addStud(2, 1, 2, BLUE, 129, 16.6, 8);
addStud(2, 1, 2, PURPLE, 137, 19.6, 0);
addStud(2, 1, 2, PINK, 146, 22.6, 8);
addStud(2, 1, 2, RED, 154, 25.6, 0);
addStud(8, 2, 8, WHITE, 160, 25.6, 0);
addStud(1, 1, 4, TEAL, 160, 25.6, 10);
addStud(1, 1, 4, PINK, 160, 25.6, 19);
addStud(1, 1, 4, TEAL, 160, 25.6, 28);
addStud(1, 1, 4, PINK, 160, 25.6, 37);
addStud(1, 1, 4, TEAL, 160, 25.6, 46);
addStud(1, 1, 4, PINK, 160, 25.6, 55);
addStud(1, 1, 4, TEAL, 160, 25.6, 64);
addStud(1, 1, 4, PINK, 160, 25.6, 73);
addStud(1, 1, 4, TEAL, 160, 25.6, 82);
addStud(1, 1, 4, PINK, 160, 25.6, 91);
addStud(6, 2, 6, WHITE, 160, 25.6, 93);
addStud(2, 1, 2, RED, 173, 25.6, 95);
addStud(2, 1, 2, ORANGE, 171.26, 28.1, 101.5);
addStud(2, 1, 2, YELLOW, 166.5, 30.6, 106.26);
addStud(2, 1, 2, LIME, 160, 33.1, 108);
addStud(2, 1, 2, TEAL, 153.5, 35.6, 106.26);
addStud(2, 1, 2, BLUE, 148.74, 38.1, 101.5);
addStud(2, 1, 2, PURPLE, 147, 40.6, 95);
addStud(2, 1, 2, PINK, 148.74, 43.1, 88.5);
addStud(2, 1, 2, WHITE, 153.5, 45.6, 83.74);
addStud(2, 1, 2, RED, 160, 48.1, 82);
addStud(2, 1, 2, ORANGE, 166.5, 50.6, 83.74);
addStud(2, 1, 2, YELLOW, 171.26, 53.1, 88.5);
addStud(6, 2, 6, WHITE, 160, 53.1, 95);
addStud(2, 2, 2, DARK, 148, 53.1, 95);
addStud(3, 1, 3, RED, 148, 55.1, 95);
addStud(2, 7, 2, DARK, 137, 53.1, 95);
addStud(3, 1, 3, ORANGE, 137, 60.1, 95);
addStud(2, 2, 2, DARK, 126, 53.1, 95);
addStud(3, 1, 3, RED, 126, 55.1, 95);
addStud(2, 7, 2, DARK, 115, 53.1, 95);
addStud(3, 1, 3, ORANGE, 115, 60.1, 95);
addStud(2, 2, 2, DARK, 104, 53.1, 95);
addStud(3, 1, 3, RED, 104, 55.1, 95);
addStud(2, 7, 2, DARK, 93, 53.1, 95);
addStud(3, 1, 3, ORANGE, 93, 60.1, 95);
addStud(2, 2, 2, DARK, 82, 53.1, 95);
addStud(3, 1, 3, RED, 82, 55.1, 95);
addStud(2, 7, 2, DARK, 71, 53.1, 95);
addStud(3, 1, 3, ORANGE, 71, 60.1, 95);
addStud(2, 2, 2, DARK, 60, 53.1, 95);
addStud(3, 1, 3, RED, 60, 55.1, 95);
addStud(2, 7, 2, DARK, 49, 53.1, 95);
addStud(3, 1, 3, ORANGE, 49, 60.1, 95);
addStud(6, 2, 6, WHITE, 41, 58.1, 95);
addStud(2, 1, 8, BLUE, 41, 58.1, 85);
addStud(8, 1, 2, BLUE, 49, 58.1, 79);
addStud(2, 1, 8, TEAL, 57, 58.1, 71);
addStud(8, 1, 2, TEAL, 49, 58.1, 63);
addStud(2, 1, 8, PURPLE, 41, 58.1, 55);
addStud(8, 1, 2, PURPLE, 33, 58.1, 47);
addStud(2, 1, 8, PINK, 25, 58.1, 39);
addStud(8, 1, 2, PINK, 33, 58.1, 31);
addStud(2, 1, 6, RED, 41, 58.1, 23);
addStud(6, 2, 6, WHITE, 41, 58.1, 17);
addStud(2, 1, 2, ORANGE, 41, 58.1, 8);
addStud(2, 1, 2, RED, 41, 60.1, 1);
addStud(2, 1, 2, YELLOW, 41, 58.1, -6);
addStud(1, 1, 2, TEAL, 41, 58.1, -13);
addStud(2, 1, 2, PURPLE, 41, 61.1, -20);
addStud(2, 1, 1, BLUE, 41, 60.1, -27);
addStud(1, 1, 1, PINK, 41, 62.1, -34);
addStud(1, 1, 1, RED, 41, 62.1, -41);
addStud(1, 1, 1, ORANGE, 41, 62.1, -48);
addStud(2, 1, 2, LIME, 41, 60.1, -55);
addStud(2, 1, 2, LIME, 41, 60.1, -62);
addStud(6, 2, 6, WHITE, 41, 60.1, -65);
addStud(2, 1, 2, RED, 53, 60.1, -61);
addStud(2, 1, 2, ORANGE, 49.99, 57.9, -68.17);
addStud(2, 1, 2, YELLOW, 43.45, 55.7, -71.72);
addStud(2, 1, 2, TEAL, 36.44, 53.5, -70.46);
addStud(2, 1, 2, BLUE, 31.99, 51.3, -65.34);
addStud(2, 1, 2, PURPLE, 31.74, 49.1, -58.89);
addStud(2, 1, 2, PINK, 35.39, 46.9, -53.96);
addStud(2, 1, 2, WHITE, 41, 44.7, -52.5);
addStud(2, 1, 2, RED, 45.99, 42.5, -54.75);
addStud(2, 1, 2, ORANGE, 48.31, 40.3, -59.33);
addStud(2, 1, 2, YELLOW, 47.31, 38.1, -64.04);
addStud(2, 1, 2, TEAL, 43.82, 35.9, -66.86);
addStud(2, 1, 2, BLUE, 39.66, 33.7, -66.85);
addStud(2, 1, 2, PURPLE, 36.7, 31.5, -64.43);
addStud(6, 2, 6, WHITE, 41, 31.5, -61);
addStud(2, 1, 2, ORANGE, 50, 31.5, -61);
addStud(2, 1, 2, BLUE, 40, 34.5, -61);
addStud(2, 1, 2, ORANGE, 50, 37.5, -61);
addStud(2, 1, 2, BLUE, 40, 40.5, -61);
addStud(2, 1, 2, YELLOW, 50, 43.5, -61);
addStud(2, 1, 2, PURPLE, 40, 46.5, -61);
addStud(2, 1, 2, YELLOW, 50, 49.5, -61);
addStud(2, 1, 2, PURPLE, 40, 52.5, -61);
addStud(2, 1, 2, RED, 50, 55.5, -61);
addStud(2, 1, 2, TEAL, 40, 58.5, -61);
addStud(2, 1, 2, RED, 50, 61.5, -61);
addStud(2, 1, 2, TEAL, 40, 64.5, -61);
addStud(6, 2, 6, WHITE, 45, 64.5, -61);
addStud(12, 1, 1, TEAL, 61, 64.5, -61);
addStud(1, 1, 12, ORANGE, 61, 64.5, -61);
addStud(12, 1, 1, TEAL, 71, 67.5, -61);
addStud(1, 1, 12, ORANGE, 71, 67.5, -61);
addStud(12, 1, 1, TEAL, 81, 64.5, -61);
addStud(1, 1, 12, ORANGE, 81, 64.5, -61);
addStud(12, 1, 1, TEAL, 91, 61.5, -61);
addStud(1, 1, 12, ORANGE, 91, 61.5, -61);
addStud(12, 1, 1, TEAL, 101, 64.5, -61);
addStud(1, 1, 12, ORANGE, 101, 64.5, -61);
addStud(12, 1, 1, TEAL, 111, 67.5, -61);
addStud(1, 1, 12, ORANGE, 111, 67.5, -61);
addStud(12, 1, 1, TEAL, 121, 64.5, -61);
addStud(1, 1, 12, ORANGE, 121, 64.5, -61);
addStud(6, 2, 6, WHITE, 125, 64.5, -61);
addStud(2, 1, 2, RED, 125, 64.5, -52);
addStud(2, 1, 2, ORANGE, 125, 59.5, -43);
addStud(2, 1, 2, YELLOW, 125, 54.5, -34);
addStud(2, 1, 2, PINK, 125, 49.5, -25);
addStud(2, 1, 2, TEAL, 125, 44.5, -16);
addStud(2, 1, 2, BLUE, 125, 39.5, -7);
addStud(2, 1, 2, PURPLE, 125, 34.5, 2);
addStud(2, 1, 2, LIME, 125, 29.5, 11);
addStud(6, 2, 6, WHITE, 125, 29.5, 15);
addStud(2, 1, 2, PINK, 134, 30.5, 19);
addStud(2, 1, 2, TEAL, 143, 29.5, 15);
addStud(2, 1, 2, RED, 152, 31.5, 19);
addStud(2, 1, 2, ORANGE, 161, 29.5, 15);
addStud(2, 1, 2, PURPLE, 170, 30.5, 21);
addStud(2, 1, 2, BLUE, 179, 29.5, 15);
addStud(2, 1, 2, YELLOW, 188, 31.5, 15);
addStud(2, 1, 2, PINK, 197, 29.5, 21);
addStud(2, 1, 2, TEAL, 206, 29.5, 15);
addStud(2, 1, 2, LIME, 215, 30.5, 15);
addStud(6, 2, 6, WHITE, 221, 30.5, 15);
addStud(1, 1, 1, RED, 231, 30.5, 15);
addStud(1, 1, 1, ORANGE, 228.07, 32.5, 22.07);
addStud(1, 1, 1, YELLOW, 221, 34.5, 25);
addStud(1, 1, 1, LIME, 213.93, 36.5, 22.07);
addStud(1, 1, 1, TEAL, 211, 38.5, 15);
addStud(1, 1, 1, BLUE, 213.93, 40.5, 7.93);
addStud(1, 1, 1, PURPLE, 221, 42.5, 5);
addStud(1, 1, 1, PINK, 228.07, 44.5, 7.93);
addStud(1, 1, 1, WHITE, 231, 46.5, 15);
addStud(1, 1, 1, RED, 228.07, 48.5, 22.07);
addStud(1, 1, 1, ORANGE, 221, 50.5, 25);
addStud(1, 1, 1, YELLOW, 213.93, 52.5, 22.07);
addStud(1, 1, 1, LIME, 211, 54.5, 15);
addStud(1, 1, 1, TEAL, 213.93, 56.5, 7.93);
addStud(1, 1, 1, BLUE, 221, 58.5, 5);
addStud(1, 1, 1, PURPLE, 228.07, 60.5, 7.93);
addStud(8, 1, 8, ORANGE, 221, 60.5, 15);
addStud(14, 3, 14, LIME, 221, 61.5, 15);
const STAIR_COLORS = [BLUE, RED, YELLOW, ORANGE, PURPLE, LIME];
for (let n = 1; n <= 10; n++) {
  addStud(6, n, 1, STAIR_COLORS[(n - 1) % STAIR_COLORS.length], -15, G, -(5 + n));
}
addStud(6, 1, 6, PURPLE, -25, G, -6);
addStud(6, 1, 6, PURPLE, -25, G + 2, -6);
addStud(6, 1, 6, PURPLE, -25, G + 4, -6);
addStud(6, 1, 6, PURPLE, -25, G + 6, -6);
addStud(6, 1, 6, PURPLE, -25, G + 8, -6);
addStud(6, 1, 6, PURPLE, -25, G + 10, -6);
addStud(6, 1, 6, PURPLE, -25, G + 12, -6);
addStud(6, 1, 6, PURPLE, -25, G + 14, -6);
addStud(6, 1, 6, PURPLE, -25, G + 16, -6);
addStud(6, 1, 6, PURPLE, -25, G + 18, -6);
addStud(6, 1, 6, PURPLE, -25, G + 20, -6);
addStud(6, 1, 6, PURPLE, -25, G + 22, -6);
{
  const canvas = document.createElement("canvas");
  canvas.width = 4096;
  canvas.height = 128;
  const ctx = canvas.getContext("2d");
  ctx.font = "bold 72px system-ui, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillStyle = "rgb(0,0,0)";
  ctx.fillText("climbing logic still work in progress. please report all bugs to the discord server!!", 2048, 64);
  const tex = new THREE.CanvasTexture(canvas);
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(128, 4), new THREE.MeshBasicMaterial({
    map: tex,
    transparent: true,
    depthWrite: false
  }));
  mesh.rotation.x = -Math.PI / 2;
  mesh.rotation.z = -Math.PI / 2;
  mesh.position.set(10, 1.62, 8);
  scene.add(mesh);
}
{
  const DEG = Math.PI / 180;
  addStud(8, 1, 8, ORANGE, -40, G, 0);
  addStud(8, 1, 16, RED, -40, G + 2.74, -12, DEG * 20, 0, 0);
  addStud(8, 1, 8, LIME, -40, G + 5.5, -24);
  addStud(6, 1, 8, BLUE, -40, G + 8, -38, DEG * 45, 0, 0);
  addStud(8, 2, 8, WHITE, -40, G + 11.5, -50);
  addStud(6, 1, 6, YELLOW, -40, G + 13.5, -62, 0, DEG * 45, 0);
  addStud(8, 1, 8, PURPLE, -40, G + 14, -75, 0, 0, DEG * 20);
}
addStud(32, 1, 58, 8947848, 0, G, 90);
window.SHIRT_PADS = [{
  x: 0,
  z: 67,
  item_id: null
}, {
  x: -10.5,
  z: 76,
  item_id: 1
}, {
  x: -3.5,
  z: 76,
  item_id: 2
}, {
  x: 3.5,
  z: 76,
  item_id: 3
}, {
  x: 10.5,
  z: 76,
  item_id: 4
}, {
  x: -10.5,
  z: 87,
  item_id: 5
}, {
  x: -3.5,
  z: 87,
  item_id: 6
}, {
  x: 3.5,
  z: 87,
  item_id: 7
}, {
  x: 10.5,
  z: 87,
  item_id: 8
}, {
  x: -10.5,
  z: 98,
  item_id: 9
}, {
  x: -3.5,
  z: 98,
  item_id: 10
}, {
  x: 3.5,
  z: 98,
  item_id: 11
}, {
  x: 10.5,
  z: 98,
  item_id: 12
}, {
  x: -10.5,
  z: 109,
  item_id: 13
}, {
  x: -3.5,
  z: 109,
  item_id: 14
}, {
  x: 3.5,
  z: 109,
  item_id: 15
}, {
  x: 10.5,
  z: 109,
  item_id: 16
}];
for (const pad of window.SHIRT_PADS) {
  const mesh = addStud(4, 0.5, 4, RED, pad.x, G + 1, pad.z);
  mesh.material = mesh.material.map(_0x186f46 => _0x186f46.clone());
  pad.mesh = mesh;
}
addStud(1, 1, 2, 8421504, -1, G + 3, 0);
addStud(1, 20, 10, 8421504, 0, G, 0);
addStud(1, 20, 10, 8421504, 0, G, 13);
addStud(1, 20, 14, 8421504, 3, G, 0);
addStud(1, 20, 6, 8421504, 3, G, 13);
if (window._vortex && window._vortex.finishWorld) {
  window._vortex.finishWorld();
}