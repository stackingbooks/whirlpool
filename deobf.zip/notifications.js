(function () {
  const _0x1f7202 = document.getElementById("notif-container");
  function _0x4b3c3b(_0x4bee3c) {
    return _0x4bee3c.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function _0x5b41aa(_0x3632b2) {
    _0x3632b2.classList.add("notif-out");
    setTimeout(() => _0x3632b2.remove(), 280);
  }
  const _0xa0714a = new Map();
  function _0x50bbba(_0x173e82, _0x2e979f) {
    if (_0xa0714a.has(_0x173e82)) {
      return;
    }
    const _0x1841d0 = document.createElement("div");
    _0x1841d0.className = "notif";
    _0x1841d0.innerHTML = "\n            <div class=\"notif-avatar\">" + _0x4b3c3b(_0x2e979f[0].toUpperCase()) + "</div>\n            <div class=\"notif-body\">\n                <div class=\"notif-title\">" + _0x4b3c3b(_0x2e979f) + "</div>\n                <div class=\"notif-sub\">wants to be your friend</div>\n                <div class=\"notif-actions\">\n                    <button class=\"notif-btn notif-accept\">Accept</button>\n                    <button class=\"notif-btn notif-decline\">Decline</button>\n                </div>\n            </div>\n        ";
    _0xa0714a.set(_0x173e82, _0x1841d0);
    const _0x2ab035 = _0x1841d0.querySelector(".notif-accept");
    const _0x4a41e4 = _0x1841d0.querySelector(".notif-decline");
    function _0x1eed1d() {
      _0x2ab035.disabled = true;
      _0x4a41e4.disabled = true;
      _0x2ab035.textContent = "...";
    }
    _0x2ab035.addEventListener("click", async () => {
      _0x1eed1d();
      const _0x1bf4ed = await fetch("/api/friends/requests/incoming");
      const _0x116ffb = await _0x1bf4ed.json().catch(() => []);
      const _0x10800e = _0x116ffb.find(_0x4a7815 => _0x4a7815.from_user_id === _0x173e82);
      if (_0x10800e) {
        const _0x17c936 = await fetch("/api/friends/accept/" + _0x10800e.id, {
          method: "POST"
        });
        if (_0x17c936.ok) {
          _0xa0714a.delete(_0x173e82);
          _0x5b41aa(_0x1841d0);
          _0x168f56(_0x2e979f);
          window._mpSetFriendStatus?.(_0x173e82, "friends");
          return;
        }
      }
      _0x2ab035.disabled = false;
      _0x4a41e4.disabled = false;
      _0x2ab035.textContent = "Accept";
    });
    _0x4a41e4.addEventListener("click", async () => {
      _0x4a41e4.disabled = true;
      _0x2ab035.disabled = true;
      _0xa0714a.delete(_0x173e82);
      _0x5b41aa(_0x1841d0);
      const _0x4a518d = await fetch("/api/friends/requests/incoming").catch(() => null);
      if (!_0x4a518d?.ok) {
        return;
      }
      const _0x93090b = await _0x4a518d.json().catch(() => []);
      const _0x1307d5 = _0x93090b.find(_0x2bb6f8 => _0x2bb6f8.from_user_id === _0x173e82);
      if (_0x1307d5) {
        fetch("/api/friends/reject/" + _0x1307d5.id, {
          method: "POST"
        }).catch(() => {});
      }
    });
    _0x1f7202.appendChild(_0x1841d0);
  }
  function _0x21f3b1(_0x19ff09) {
    const _0x590dd0 = _0xa0714a.get(_0x19ff09);
    if (_0x590dd0) {
      _0xa0714a.delete(_0x19ff09);
      _0x5b41aa(_0x590dd0);
    }
  }
  function _0x168f56(_0x170cf8) {
    const _0x122e33 = document.createElement("div");
    _0x122e33.className = "notif notif-success";
    _0x122e33.innerHTML = "\n            <div class=\"notif-avatar notif-avatar-success\">✓</div>\n            <div class=\"notif-body\">\n                <div class=\"notif-title\">You're friends!</div>\n                <div class=\"notif-sub\">You and " + _0x4b3c3b(_0x170cf8) + " are now friends.</div>\n            </div>\n        ";
    _0x1f7202.appendChild(_0x122e33);
    setTimeout(() => _0x5b41aa(_0x122e33), 6000);
  }
  function _0x75436c(_0x5193eb) {
    const _0x3a37aa = document.createElement("div");
    _0x3a37aa.className = "notif notif-success";
    _0x3a37aa.innerHTML = "\n            <div class=\"notif-body\">\n                <div class=\"notif-title\">" + _0x4b3c3b(_0x5193eb) + "</div>\n            </div>\n        ";
    _0x1f7202.appendChild(_0x3a37aa);
    setTimeout(() => _0x5b41aa(_0x3a37aa), 5000);
  }
  window.Notifications = {
    friendRequest: _0x50bbba,
    friendRequestCancelled: _0x21f3b1,
    friendAccepted: _0x168f56,
    followed: _0x506fd5 => _0x75436c(_0x506fd5 + " followed you"),
    unfollowed: _0x2b764e => _0x75436c(_0x2b764e + " unfollowed you")
  };
})();