(function () {
  const _0x62541e = document.getElementById("leaderboard");
  const _0x8ae842 = document.getElementById("lb-body");
  const _0x5bd4e0 = document.getElementById("lb-col-headers");
  const _0x214476 = document.getElementById("lb-player-panel");
  const _0xf8bf9f = document.getElementById("lbp-name");
  const _0x5602ec = document.getElementById("lbp-action-btn");
  const _0x2a3893 = document.getElementById("lbp-follow-btn");
  const _0x276a69 = document.getElementById("lbp-profile-link");
  let _0xf8c480 = null;
  let _0x42cc10 = [];
  let _0x292a72 = [];
  let _0x2ab384 = true;
  let _0x1de9c3 = null;
  let _0x5ba435 = {};
  let _0x211a7b = {};
  const _0x5f0435 = "<i class=\"fa-solid fa-user lb-friend-icon\"></i>";
  const _0x466d66 = "<i class=\"fa-solid fa-shield-halved lb-staff-icon\"></i>";
  const _0x2702c2 = "<svg class=\"lb-boost-icon\" xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" fill=\"none\" viewBox=\"0 0 24 24\"><path fill=\"#FF4DA5\" d=\"M12.4801 1.42383C12.202 1.19206 11.798 1.19206 11.5199 1.42383L5.51986 6.42383C5.34887 6.56633 5.25 6.77742 5.25 7V17C5.25 17.2226 5.34887 17.4337 5.51986 17.5762L11.5199 22.5762C11.798 22.8079 12.202 22.8079 12.4801 22.5762L18.4801 17.5762C18.6511 17.4337 18.75 17.2226 18.75 17V7C18.75 6.77742 18.6511 6.56633 18.4801 6.42383L12.4801 1.42383Z\"/><path fill=\"#ECEFF1\" fill-rule=\"evenodd\" d=\"M11.4932 5.44713C11.7799 5.18429 12.2201 5.18429 12.5068 5.44713L15.5068 8.19713C15.6618 8.33919 15.75 8.53977 15.75 8.75V15.25C15.75 15.4602 15.6618 15.6608 15.5068 15.8029L12.5068 18.5529C12.2201 18.8157 11.7799 18.8157 11.4932 18.5529L8.49321 15.8029C8.33823 15.6608 8.25 15.4602 8.25 15.25V8.75C8.25 8.53977 8.33823 8.33919 8.49321 8.19713L11.4932 5.44713ZM9.75 9.07993V14.9201L12 16.9826L14.25 14.9201V9.07993L12 7.01743L9.75 9.07993Z\" clip-rule=\"evenodd\"/><path fill=\"#E54594\" fill-rule=\"evenodd\" d=\"M12 1.25V22.75C11.8295 22.75 11.6589 22.6921 11.5199 22.5762L5.51986 17.5762C5.34887 17.4337 5.25 17.2226 5.25 17V7C5.25 6.77742 5.34887 6.56633 5.51986 6.42383L11.5199 1.42383C11.6589 1.30794 11.8295 1.25 12 1.25Z\" clip-rule=\"evenodd\"/><path fill=\"#D4D6D8\" fill-rule=\"evenodd\" d=\"M12 5.25C11.8183 5.25 11.6366 5.31571 11.4932 5.44713L8.49321 8.19713C8.33823 8.33919 8.25 8.53977 8.25 8.75V15.25C8.25 15.4602 8.33823 15.6608 8.49321 15.8029L11.4932 18.5529C11.6366 18.6843 11.8183 18.75 12 18.75V16.9826L9.75 14.9201V9.07993L12 7.01743V5.25Z\" clip-rule=\"evenodd\"/></svg>";
  function _0x22a110(_0x5aff83) {
    if (_0x5aff83.is_staff) {
      return _0x466d66;
    }
    if (_0x5aff83.is_booster) {
      return _0x2702c2;
    }
    return null;
  }
  function _0x2dcdb0() {
    _0x5bd4e0.innerHTML = "";
    for (const _0x4378a5 of _0x42cc10) {
      const _0x1db076 = document.createElement("span");
      _0x1db076.className = "lb-col-label";
      _0x1db076.textContent = _0x4378a5.label;
      _0x5bd4e0.appendChild(_0x1db076);
    }
    _0x8ae842.innerHTML = "";
    for (const _0x589796 of _0x292a72) {
      const _0x3a8b7e = _0x589796.id === _0xf8c480;
      const _0x5e5317 = _0x5ba435[_0x589796.id];
      const _0x462c97 = document.createElement("div");
      _0x462c97.className = "lb-row" + (_0x3a8b7e ? " lb-self" : " lb-clickable");
      if (!_0x3a8b7e) {
        _0x462c97.dataset.playerId = _0x589796.id;
      }
      const _0x3d19b3 = document.createElement("span");
      _0x3d19b3.className = "lb-name";
      const _0x1c0e18 = _0x589796.username.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      const _0x45c85e = !_0x3a8b7e && _0x5e5317 === "friends" ? _0x5f0435 : _0x22a110(_0x589796) ?? "";
      _0x3d19b3.innerHTML = "<span class=\"lb-badge-slot\">" + _0x45c85e + "</span>" + _0x1c0e18;
      _0x462c97.appendChild(_0x3d19b3);
      for (const _0x326640 of _0x42cc10) {
        const _0xce30cd = document.createElement("span");
        _0xce30cd.className = "lb-col-val";
        _0xce30cd.textContent = _0x589796[_0x326640.key] ?? "—";
        _0x462c97.appendChild(_0xce30cd);
      }
      _0x8ae842.appendChild(_0x462c97);
    }
  }
  function _0x4d5d7d(_0x3a6e1f, _0x7e58b) {
    _0x211a7b[_0x7e58b] = _0x3a6e1f;
    _0x2a3893.onclick = null;
    _0x2a3893.disabled = false;
    if (_0x3a6e1f === "following") {
      _0x2a3893.textContent = "Following";
      _0x2a3893.className = "lbp-btn lbp-following";
      _0x2a3893.onclick = async () => {
        _0x2a3893.disabled = true;
        _0x2a3893.textContent = "...";
        const _0x13fe68 = await fetch("/api/follow/" + _0x7e58b, {
          method: "DELETE"
        });
        if (_0x1de9c3 !== _0x7e58b) {
          return;
        }
        if (_0x13fe68.ok) {
          _0x4d5d7d("not_following", _0x7e58b);
        } else {
          _0x4d5d7d("following", _0x7e58b);
        }
      };
    } else {
      _0x2a3893.textContent = "Follow";
      _0x2a3893.className = "lbp-btn lbp-add";
      _0x2a3893.onclick = async () => {
        _0x2a3893.disabled = true;
        _0x2a3893.textContent = "...";
        const _0x3a4577 = await fetch("/api/follow/" + _0x7e58b, {
          method: "POST"
        });
        if (_0x1de9c3 !== _0x7e58b) {
          return;
        }
        if (_0x3a4577.ok) {
          _0x4d5d7d("following", _0x7e58b);
        } else {
          _0x4d5d7d("not_following", _0x7e58b);
        }
      };
    }
  }
  function _0x1a50fa(_0x47cc6b) {
    if (_0x1de9c3 === _0x47cc6b) {
      _0x1de9c3 = null;
      _0x214476.style.display = "none";
      return;
    }
    _0x1de9c3 = _0x47cc6b;
    const _0x5cb085 = _0x292a72.find(_0x55ca31 => _0x55ca31.id === _0x47cc6b);
    _0xf8bf9f.textContent = _0x5cb085?.username ?? "";
    _0x276a69.href = "/users/" + _0x47cc6b + "/profile";
    _0x214476.style.display = "";
    _0x535534(_0x5ba435[_0x47cc6b] ?? "none", _0x47cc6b);
    if (_0x211a7b[_0x47cc6b] != null) {
      _0x4d5d7d(_0x211a7b[_0x47cc6b], _0x47cc6b);
    } else {
      _0x2a3893.textContent = "...";
      _0x2a3893.className = "lbp-btn";
      _0x2a3893.disabled = true;
      fetch("/api/follow/" + _0x47cc6b).then(_0x2badde => _0x2badde.ok ? _0x2badde.json() : null).then(_0x3db4d6 => {
        if (_0x1de9c3 !== _0x47cc6b || !_0x3db4d6) {
          return;
        }
        _0x4d5d7d(_0x3db4d6.status, _0x47cc6b);
      });
    }
  }
  function _0x535534(_0x4b0052, _0x5b0031) {
    _0x5ba435[_0x5b0031] = _0x4b0052;
    _0x5602ec.onclick = null;
    _0x5602ec.disabled = false;
    if (_0x4b0052 === "none") {
      _0x5602ec.textContent = "Add Friend";
      _0x5602ec.className = "lbp-btn lbp-add";
      _0x5602ec.onclick = async () => {
        _0x5602ec.disabled = true;
        _0x5602ec.textContent = "...";
        const _0x3abadd = await fetch("/api/friends/request/" + _0x5b0031, {
          method: "POST"
        });
        const _0x58fd70 = await _0x3abadd.json().catch(() => ({}));
        if (_0x1de9c3 !== _0x5b0031) {
          return;
        }
        if (_0x3abadd.ok) {
          if (_0x58fd70.result === "accepted") {
            _0x535534("friends", _0x5b0031);
            window._mpSetFriendStatus?.(_0x5b0031, "friends");
            window.Notifications?.friendAccepted(_0x58fd70.target_username);
          } else {
            _0x535534("request_sent", _0x5b0031);
            window._mpSetFriendStatus?.(_0x5b0031, "request_sent");
          }
          _0x2dcdb0();
        } else {
          _0x535534("none", _0x5b0031);
        }
      };
    } else if (_0x4b0052 === "friends") {
      _0x5602ec.textContent = "Friends ✓";
      _0x5602ec.className = "lbp-btn lbp-friends";
    } else if (_0x4b0052 === "request_sent") {
      _0x5602ec.textContent = "Cancel Request";
      _0x5602ec.className = "lbp-btn lbp-pending";
      _0x5602ec.onclick = async () => {
        _0x5602ec.disabled = true;
        _0x5602ec.textContent = "...";
        const _0x6b827 = await fetch("/api/friends/request/" + _0x5b0031, {
          method: "DELETE"
        });
        if (_0x1de9c3 !== _0x5b0031) {
          return;
        }
        if (_0x6b827.ok) {
          _0x535534("none", _0x5b0031);
          window._mpSetFriendStatus?.(_0x5b0031, "none");
          _0x2dcdb0();
        } else {
          _0x535534("request_sent", _0x5b0031);
        }
      };
    } else if (_0x4b0052 === "request_received") {
      _0x5602ec.textContent = "Accept Request";
      _0x5602ec.className = "lbp-btn lbp-add";
      _0x5602ec.onclick = async () => {
        _0x5602ec.disabled = true;
        _0x5602ec.textContent = "...";
        const _0x2001d3 = await fetch("/api/friends/requests/incoming");
        const _0x1dcb96 = await _0x2001d3.json().catch(() => []);
        const _0x559575 = _0x1dcb96.find(_0x334c45 => _0x334c45.from_user_id === _0x5b0031);
        if (_0x1de9c3 !== _0x5b0031) {
          return;
        }
        if (_0x559575) {
          const _0xffb951 = await fetch("/api/friends/accept/" + _0x559575.id, {
            method: "POST"
          });
          if (_0xffb951.ok) {
            _0x535534("friends", _0x5b0031);
            window._mpSetFriendStatus?.(_0x5b0031, "friends");
            window.Notifications?.friendAccepted(_0xf8bf9f.textContent);
            _0x2dcdb0();
            return;
          }
        }
        _0x535534("request_received", _0x5b0031);
      };
    }
  }
  document.addEventListener("keydown", _0x4df08a => {
    if (_0x4df08a.code === "Tab") {
      _0x4df08a.preventDefault();
      _0x2ab384 = !_0x2ab384;
      _0x62541e.style.display = _0x2ab384 ? "" : "none";
      if (!_0x2ab384) {
        _0x1de9c3 = null;
        _0x214476.style.display = "none";
      }
    }
  });
  window.Leaderboard = {
    setMyId(_0x1f68d9) {
      _0xf8c480 = _0x1f68d9;
      _0x2dcdb0();
    },
    setColumns(_0x5ad0ab) {
      _0x42cc10 = _0x5ad0ab;
      _0x2dcdb0();
    },
    setPlayers(_0x31f9ec) {
      _0x292a72 = [..._0x31f9ec];
      _0x2dcdb0();
    },
    addPlayer(_0x1f9771) {
      const _0x132f5f = _0x292a72.findIndex(_0x46df96 => _0x46df96.id === _0x1f9771.id);
      if (_0x132f5f >= 0) {
        _0x292a72[_0x132f5f] = _0x1f9771;
      } else {
        _0x292a72.push(_0x1f9771);
      }
      _0x2dcdb0();
    },
    removePlayer(_0x47b70b) {
      _0x292a72 = _0x292a72.filter(_0x281166 => _0x281166.id !== _0x47b70b);
      if (_0x1de9c3 === _0x47b70b) {
        _0x1de9c3 = null;
        _0x214476.style.display = "none";
      }
      _0x2dcdb0();
    },
    updateStat(_0x52c0a4, _0x3ca457, _0x448fca) {
      const _0x4d37de = _0x292a72.find(_0x3d46b8 => _0x3d46b8.id === _0x52c0a4);
      if (_0x4d37de) {
        _0x4d37de[_0x3ca457] = _0x448fca;
        _0x2dcdb0();
      }
    },
    batchUpdateStat(_0x3042ba) {
      for (const {
        id: _0x442691,
        key: _0x58c06e,
        value: _0x43ee1e
      } of _0x3042ba) {
        const _0x28d1cd = _0x292a72.find(_0x2354d8 => _0x2354d8.id === _0x442691);
        if (_0x28d1cd) {
          _0x28d1cd[_0x58c06e] = _0x43ee1e;
        }
      }
      _0x2dcdb0();
    },
    setFriendStatuses(_0x353c32) {
      _0x5ba435 = {
        ..._0x5ba435,
        ..._0x353c32
      };
      _0x2dcdb0();
    },
    setFriendStatus(_0x4ff8bf, _0x2fb8b8) {
      _0x5ba435[_0x4ff8bf] = _0x2fb8b8;
      _0x2dcdb0();
    },
    setFollowStatus(_0x9396fc, _0x46aa79) {
      _0x211a7b[_0x9396fc] = _0x46aa79;
      if (_0x1de9c3 === _0x9396fc) {
        _0x4d5d7d(_0x46aa79, _0x9396fc);
      }
    },
    selectPlayer: _0x1a50fa,
    closeFriendPanel() {
      _0x1de9c3 = null;
      _0x214476.style.display = "none";
    },
    show() {
      _0x2ab384 = true;
      _0x62541e.style.display = "";
    },
    hide() {
      _0x2ab384 = false;
      _0x62541e.style.display = "none";
    }
  };
})();