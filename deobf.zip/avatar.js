let _texLoader = null;
function _applyShirtToMesh(_0x14ec22, _0x408e43) {
  if (!_0x14ec22) {
    return;
  }
  if (!_0x408e43) {
    _0x14ec22.visible = false;
    return;
  }
  if (!_texLoader) {
    _texLoader = new THREE.TextureLoader();
  }
  _texLoader.load(_0x408e43, _0x4ea92c => {
    _0x4ea92c.colorSpace = THREE.SRGBColorSpace;
    _0x14ec22.material.map?.dispose();
    _0x14ec22.material.map = _0x4ea92c;
    _0x14ec22.material.needsUpdate = true;
    _0x14ec22.visible = true;
  });
}
function _buildShirtOverlay(_0x151ca8) {
  const _0x167f85 = 585;
  const _0x24a83d = 559;
  function _0x3e293a(_0xa7eff4, _0x46257d, _0x1459d3, _0x2558df) {
    return [_0xa7eff4 / _0x167f85, 1 - (_0x46257d + _0x2558df) / _0x24a83d, (_0xa7eff4 + _0x1459d3) / _0x167f85, 1 - _0x46257d / _0x24a83d];
  }
  const _0x3a54ed = {
    top: _0x3e293a(231, 8, 128, 64),
    front: _0x3e293a(231, 74, 128, 128),
    bottom: _0x3e293a(231, 204, 128, 64),
    left: _0x3e293a(361, 74, 64, 128),
    right: _0x3e293a(165, 74, 64, 128),
    back: _0x3e293a(427, 74, 128, 128)
  };
  const _0x2cd4b3 = {
    top: _0x3e293a(217, 289, 64, 64),
    left: _0x3e293a(19, 355, 64, 128),
    front: _0x3e293a(217, 355, 64, 128),
    right: _0x3e293a(151, 355, 64, 128),
    back: _0x3e293a(85, 355, 64, 128),
    bottom: _0x3e293a(217, 485, 64, 64)
  };
  const _0x21ea51 = {
    top: _0x3e293a(308, 289, 64, 64),
    front: _0x3e293a(308, 355, 64, 128),
    left: _0x3e293a(374, 355, 64, 128),
    right: _0x3e293a(506, 355, 64, 128),
    back: _0x3e293a(440, 355, 64, 128),
    bottom: _0x3e293a(308, 485, 64, 64)
  };
  let _0x2ab43b = null;
  _0x151ca8.traverse(_0x5c5307 => {
    if (_0x5c5307.isSkinnedMesh && !_0x2ab43b) {
      _0x2ab43b = _0x5c5307;
    }
  });
  if (!_0x2ab43b) {
    return null;
  }
  const _0x115605 = _0x2ab43b.geometry;
  const _0x35747a = _0x115605.attributes.position.array;
  const _0x451b96 = _0x115605.attributes.normal.array;
  const _0x3c25b3 = _0x115605.attributes.skinIndex.array;
  const _0x4b3f58 = _0x115605.attributes.skinWeight.array;
  const _0x58a385 = _0x115605.index ? _0x115605.index.array : null;
  const _0x11aa66 = _0x2ab43b.skeleton.bones.map(_0x143ff1 => _0x143ff1.name);
  const _0x4d7d46 = new Set(["Torso", "Left_Arm", "Right_Arm"]);
  function _0x576c40(_0x37b6d3) {
    let _0x396b50 = -1;
    let _0x4388e3 = "";
    for (let _0x35f2a5 = 0; _0x35f2a5 < 4; _0x35f2a5++) {
      const _0x26bd36 = _0x4b3f58[_0x37b6d3 * 4 + _0x35f2a5];
      if (_0x26bd36 > _0x396b50) {
        _0x396b50 = _0x26bd36;
        _0x4388e3 = _0x11aa66[_0x3c25b3[_0x37b6d3 * 4 + _0x35f2a5]] || "";
      }
    }
    return _0x4388e3;
  }
  function _0x2ef1f6(_0x31a6c7, _0x471743) {
    if (_0x58a385) {
      return _0x58a385[_0x31a6c7 * 3 + _0x471743];
    } else {
      return _0x31a6c7 * 3 + _0x471743;
    }
  }
  const _0x56342a = _0x58a385 ? _0x58a385.length / 3 : _0x35747a.length / 9;
  function _0x269792(_0x581af3, _0xa87b41, _0x35acd5) {
    const _0x2aa520 = _0x576c40(_0x581af3);
    const _0x2f59c6 = _0x576c40(_0xa87b41);
    const _0xaebe4d = _0x576c40(_0x35acd5);
    if (_0x4d7d46.has(_0x2aa520) && _0x2aa520 === _0x2f59c6 && _0x2aa520 === _0xaebe4d) {
      return _0x2aa520;
    }
    if (_0x4d7d46.has(_0x2aa520) && _0x2aa520 === _0x2f59c6) {
      return _0x2aa520;
    }
    if (_0x4d7d46.has(_0x2f59c6) && _0x2f59c6 === _0xaebe4d) {
      return _0x2f59c6;
    }
    if (_0x4d7d46.has(_0x2aa520)) {
      return _0x2aa520;
    }
    return null;
  }
  const _0x57af08 = {};
  for (const _0x4c8847 of _0x4d7d46) {
    _0x57af08[_0x4c8847] = {
      xMin: 1000000000,
      xMax: -1000000000,
      yMin: 1000000000,
      yMax: -1000000000,
      zMin: 1000000000,
      zMax: -1000000000
    };
  }
  for (let _0x3decd1 = 0; _0x3decd1 < _0x56342a; _0x3decd1++) {
    const _0x2dbfc6 = _0x2ef1f6(_0x3decd1, 0);
    const _0x5e0bd6 = _0x2ef1f6(_0x3decd1, 1);
    const _0x2094ad = _0x2ef1f6(_0x3decd1, 2);
    const _0x3128f9 = _0x269792(_0x2dbfc6, _0x5e0bd6, _0x2094ad);
    if (!_0x3128f9) {
      continue;
    }
    for (const _0x11bfbf of [_0x2dbfc6, _0x5e0bd6, _0x2094ad]) {
      const _0x11995c = _0x35747a[_0x11bfbf * 3];
      const _0x50a858 = _0x35747a[_0x11bfbf * 3 + 1];
      const _0x8ece7e = _0x35747a[_0x11bfbf * 3 + 2];
      const _0x41336e = _0x57af08[_0x3128f9];
      _0x41336e.xMin = Math.min(_0x41336e.xMin, _0x11995c);
      _0x41336e.xMax = Math.max(_0x41336e.xMax, _0x11995c);
      _0x41336e.yMin = Math.min(_0x41336e.yMin, _0x50a858);
      _0x41336e.yMax = Math.max(_0x41336e.yMax, _0x50a858);
      _0x41336e.zMin = Math.min(_0x41336e.zMin, _0x8ece7e);
      _0x41336e.zMax = Math.max(_0x41336e.zMax, _0x8ece7e);
    }
  }
  function _0x59084e(_0x1d7c42, _0xde47ee, _0x5b7fa7) {
    if (_0x5b7fa7 > _0xde47ee) {
      return (_0x1d7c42 - _0xde47ee) / (_0x5b7fa7 - _0xde47ee);
    } else {
      return 0.5;
    }
  }
  const _0x4db1d6 = [];
  const _0x1186c7 = [];
  const _0x441245 = [];
  const _0xa74c2c = [];
  const _0x5e7a95 = [];
  for (let _0x45b0e6 = 0; _0x45b0e6 < _0x56342a; _0x45b0e6++) {
    const _0x121d9a = _0x2ef1f6(_0x45b0e6, 0);
    const _0x2b2cdb = _0x2ef1f6(_0x45b0e6, 1);
    const _0x259f7f = _0x2ef1f6(_0x45b0e6, 2);
    const _0xae2a23 = _0x269792(_0x121d9a, _0x2b2cdb, _0x259f7f);
    if (!_0xae2a23) {
      continue;
    }
    const _0x2fbdae = [_0x121d9a, _0x2b2cdb, _0x259f7f].map(_0x393b36 => [_0x451b96[_0x393b36 * 3], _0x451b96[_0x393b36 * 3 + 1], _0x451b96[_0x393b36 * 3 + 2]]);
    let _0x2dd078 = (_0x2fbdae[0][0] + _0x2fbdae[1][0] + _0x2fbdae[2][0]) / 3;
    let _0x3cae28 = (_0x2fbdae[0][1] + _0x2fbdae[1][1] + _0x2fbdae[2][1]) / 3;
    let _0x4161d1 = (_0x2fbdae[0][2] + _0x2fbdae[1][2] + _0x2fbdae[2][2]) / 3;
    const _0x117a64 = Math.sqrt(_0x2dd078 * _0x2dd078 + _0x3cae28 * _0x3cae28 + _0x4161d1 * _0x4161d1) || 1;
    _0x2dd078 /= _0x117a64;
    _0x3cae28 /= _0x117a64;
    _0x4161d1 /= _0x117a64;
    const _0x4281bf = Math.abs(_0x2dd078);
    const _0xd79b74 = Math.abs(_0x3cae28);
    const _0x3d2eb2 = Math.abs(_0x4161d1);
    const _0x3f6244 = Math.max(_0x4281bf, _0xd79b74, _0x3d2eb2);
    const _0x1eef9c = _0x3f6244 === _0x4281bf ? Math.sign(_0x2dd078) : 0;
    const _0x6550d2 = _0x3f6244 === _0xd79b74 ? Math.sign(_0x3cae28) : 0;
    const _0x3b0200 = _0x3f6244 === _0x3d2eb2 ? Math.sign(_0x4161d1) : 0;
    let _0x5963bf;
    if (_0x6550d2 > 0) {
      _0x5963bf = "front";
    } else if (_0x6550d2 < 0) {
      _0x5963bf = "back";
    } else if (_0x1eef9c > 0) {
      _0x5963bf = "+x";
    } else if (_0x1eef9c < 0) {
      _0x5963bf = "-x";
    } else if (_0x3b0200 > 0) {
      _0x5963bf = "top";
    } else {
      _0x5963bf = "bottom";
    }
    const _0x49e058 = _0xae2a23 === "Torso" ? _0x3a54ed : _0xae2a23 === "Right_Arm" ? _0x2cd4b3 : _0x21ea51;
    const _0x3071fb = {
      front: _0x49e058.front,
      back: _0x49e058.back,
      top: _0x49e058.bottom,
      bottom: _0x49e058.top,
      "+x": _0x49e058.left,
      "-x": _0x49e058.right
    }[_0x5963bf];
    const _0x36e19d = _0x57af08[_0xae2a23];
    for (let _0x5a0ddd = 0; _0x5a0ddd < 3; _0x5a0ddd++) {
      const _0x41e651 = [_0x121d9a, _0x2b2cdb, _0x259f7f][_0x5a0ddd];
      const _0x52e588 = _0x35747a[_0x41e651 * 3];
      const _0x496364 = _0x35747a[_0x41e651 * 3 + 1];
      const _0x5169c8 = _0x35747a[_0x41e651 * 3 + 2];
      const _0x51db56 = _0x59084e(_0x52e588, _0x36e19d.xMin, _0x36e19d.xMax);
      const _0x3bb1fb = _0x59084e(_0x496364, _0x36e19d.yMin, _0x36e19d.yMax);
      const _0x27c7d6 = _0x59084e(_0x5169c8, _0x36e19d.zMin, _0x36e19d.zMax);
      let _0x3afca3;
      let _0x3bd32b;
      switch (_0x5963bf) {
        case "front":
          _0x3afca3 = _0x51db56;
          _0x3bd32b = 1 - _0x27c7d6;
          break;
        case "back":
          _0x3afca3 = _0x51db56;
          _0x3bd32b = 1 - _0x27c7d6;
          break;
        case "+x":
          _0x3afca3 = _0x3bb1fb;
          _0x3bd32b = 1 - _0x27c7d6;
          break;
        case "-x":
          _0x3afca3 = 1 - _0x3bb1fb;
          _0x3bd32b = 1 - _0x27c7d6;
          break;
        case "top":
          _0x3afca3 = 1 - _0x51db56;
          _0x3bd32b = _0x3bb1fb;
          break;
        case "bottom":
          _0x3afca3 = 1 - _0x51db56;
          _0x3bd32b = 1 - _0x3bb1fb;
          break;
      }
      _0x3afca3 = Math.min(1, Math.max(0, _0x3afca3));
      _0x3bd32b = Math.min(1, Math.max(0, _0x3bd32b));
      _0x4db1d6.push(_0x52e588, _0x496364, _0x5169c8);
      _0x1186c7.push(_0x451b96[_0x41e651 * 3], _0x451b96[_0x41e651 * 3 + 1], _0x451b96[_0x41e651 * 3 + 2]);
      const [_0xafbbd5, _0x49d9df, _0x5ab8a1, _0x15b464] = _0x3071fb;
      _0x441245.push(_0xafbbd5 + _0x3afca3 * (_0x5ab8a1 - _0xafbbd5), _0x49d9df + _0x3bd32b * (_0x15b464 - _0x49d9df));
      for (let _0x937a0b = 0; _0x937a0b < 4; _0x937a0b++) {
        _0xa74c2c.push(_0x3c25b3[_0x41e651 * 4 + _0x937a0b]);
        _0x5e7a95.push(_0x4b3f58[_0x41e651 * 4 + _0x937a0b]);
      }
    }
  }
  if (!_0x4db1d6.length) {
    console.warn("[avatar] no shirt faces found");
    return null;
  }
  const _0x3e05cb = new THREE.BufferGeometry();
  _0x3e05cb.setAttribute("position", new THREE.BufferAttribute(new Float32Array(_0x4db1d6), 3));
  _0x3e05cb.setAttribute("normal", new THREE.BufferAttribute(new Float32Array(_0x1186c7), 3));
  _0x3e05cb.setAttribute("uv", new THREE.BufferAttribute(new Float32Array(_0x441245), 2));
  _0x3e05cb.setAttribute("skinIndex", new THREE.BufferAttribute(new Uint16Array(_0xa74c2c), 4));
  _0x3e05cb.setAttribute("skinWeight", new THREE.BufferAttribute(new Float32Array(_0x5e7a95), 4));
  const _0x1be993 = new THREE.SkinnedMesh(_0x3e05cb, new THREE.MeshLambertMaterial({
    transparent: true,
    depthWrite: false,
    alphaTest: 0.01,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -4
  }));
  _0x1be993.name = "ShirtOverlay";
  _0x1be993.visible = false;
  _0x1be993.renderOrder = 1;
  _0x1be993.bind(_0x2ab43b.skeleton, _0x2ab43b.bindMatrix);
  _0x2ab43b.parent.add(_0x1be993);
  return _0x1be993;
}